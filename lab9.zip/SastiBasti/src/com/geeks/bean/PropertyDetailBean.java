package com.geeks.bean;

import java.io.Serializable;

public class PropertyDetailBean extends Bean implements Serializable {

	private Integer propertyDetailId;
	private String propertyDetailType;
	private String path;
	private String details;
	private PropertyBean propertyBean;

	public PropertyDetailBean() {
	}

	public Integer getPropertyDetailId() {
		return propertyDetailId;
	}

	public void setPropertyDetailId(Integer propertyDetailId) {
		this.propertyDetailId = propertyDetailId;
	}

	public String getPropertyDetailType() {
		return propertyDetailType;
	}

	public void setPropertyDetailType(String propertyType) {
		this.propertyDetailType = propertyType;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public PropertyBean getPropertyBean() {
		return propertyBean;
	}

	public void setPropertyBean(PropertyBean propertyBean) {
		this.propertyBean = propertyBean;
	}

	@Override
	public String toString() {
		return "PropertyDetailBean [propertyDetailId=" + propertyDetailId + ", propertyDetailType=" + propertyDetailType
				+ ", path=" + path + ", details=" + details + ", propertyBean=" + propertyBean + "]";
	}

}
