package com.geeks.bean;

import java.io.Serializable;

public class LocationBean extends Bean implements Serializable {

	private Integer LocationId;
	private Integer parentLocation;
	private String location;

	public LocationBean() {
	}

	public Integer getLocationId() {
		return LocationId;
	}

	public void setLocationId(Integer locationId) {
		LocationId = locationId;
	}

	public Integer getParentLocation() {
		return parentLocation;
	}

	public void setParentLocation(Integer parentLocation) {
		this.parentLocation = parentLocation;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "LocationBean [LocationId=" + LocationId + ", parentLocation=" + parentLocation + ", location="
				+ location + "]";
	}

}
