package com.geeks.bean;

import java.io.Serializable;

public class RatingBean extends Bean implements Serializable {

	private Integer ratingId;
	private UserBean userBean;
	private PropertyBean propertyBean;
	private double rating;

	public RatingBean() {
	}

	public Integer getRatingId() {
		return ratingId;
	}

	public void setRatingId(Integer ratingId) {
		this.ratingId = ratingId;
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}

	public PropertyBean getPropertyBean() {
		return propertyBean;
	}

	public void setPropertyBean(PropertyBean propertyBean) {
		this.propertyBean = propertyBean;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "RatingBean [ratingId=" + ratingId + ", userBean=" + userBean + ", propertyBean=" + propertyBean
				+ ", rating=" + rating + "]";
	}

}
