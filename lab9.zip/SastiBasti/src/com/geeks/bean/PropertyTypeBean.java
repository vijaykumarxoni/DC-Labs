package com.geeks.bean;

import java.io.Serializable;

public class PropertyTypeBean extends Bean implements Serializable {
	private Integer propertyTypeId;
	private String ptype;

	public PropertyTypeBean() {

	}

	public Integer getPropertyTypeId() {
		return propertyTypeId;
	}

	public void setPropertyTypeId(Integer propertyTypeId) {
		this.propertyTypeId = propertyTypeId;
	}

	public String getPtype() {
		return ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}

	@Override
	public String toString() {
		return "PropertyTypeBean [propertyTypeId=" + propertyTypeId + ", ptype=" + ptype + "]";
	}

}
