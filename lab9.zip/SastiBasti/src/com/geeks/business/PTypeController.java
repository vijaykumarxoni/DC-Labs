package com.geeks.business;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.geeks.bean.PropertyTypeBean;
import com.geeks.bean.UserBean;
import com.geeks.dao.PropertyTypeDao;
import com.geeks.daoImpl.PropertyTypeDaoImpl;
import com.geeks.util.CurrentDate;

/**
 * Servlet implementation class PTypeController
 */
@WebServlet("/PTypeController")
public class PTypeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PTypeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PropertyTypeDao pTypeDao = new PropertyTypeDaoImpl();
		HttpSession session = request.getSession();
		PrintWriter pw = response.getWriter();
		response.getWriter().write("vk here");
		pw.write("ssss" + request.getParameter("ptypeId"));

		if (request.getParameter("savePType") != null) {
			String pType = request.getParameter("ptype");
			PropertyTypeBean ptb = new PropertyTypeBean();
			ptb.setPtype(pType);
			UserBean userBean = (UserBean) session.getAttribute("user");
			ptb.setCreatedBy(userBean.getUserId());
			ptb.setCreatedAt(CurrentDate.getCurrentDate());
			pTypeDao.addPropertyType(ptb);
			response.sendRedirect("admin/view-property-types.jsp");
		} else if (request.getParameter("ptypeId") != null) {
			String pType = request.getParameter("ptype");
			PropertyTypeBean ptb = new PropertyTypeBean();
			Integer pTypeId = Integer.parseInt(request.getParameter("ptypeId"));
			ptb.setPropertyTypeId(pTypeId);
			ptb.setPtype(pType);
			UserBean userBean = (UserBean) session.getAttribute("user");
			ptb.setUpdatedBy(userBean.getUserId());
			ptb.setUpdatedAt(CurrentDate.getCurrentDate());
			System.out.print(pTypeDao.updatePropertyType(ptb));
			System.out.print(ptb.toString());
			response.sendRedirect("admin/view-property-types.jsp");
		}
		else if(request.getParameter("delete_ptype_id")!=null){
			
			Integer ptypeId=Integer.parseInt(""+request.getParameter("delete_ptype_id"));
			pTypeDao.deletePropertyType(ptypeId);
			response.sendRedirect("admin/view-property-types.jsp");

			
		}
}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		

	}

}
