package com.geeks.business;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.geeks.bean.UserBean;
import com.geeks.dao.UserDao;
import com.geeks.daoImpl.UserDaoImpl;
import com.geeks.util.CurrentDate;

/**
 * Servlet implementation class FileHandler
 */
@WebServlet("/FileHandler")
public class FileHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileHandler() {
		super();
		// TODO Auto-generated constructor stub

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	private final String UPLOAD_DIRECTORY = "G:/images";

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserBean userBean = new UserBean();
		HttpSession session = request.getSession();
		UserBean user = (UserBean) session.getAttribute("user");
		int updateUserid = 0;

		// process only if its multipart content
		if (ServletFileUpload.isMultipartContent(request)) {
			String pictureUrl = "";
			try {
				List<FileItem> multiparts = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(request);

				for (FileItem item : multiparts) {
					if (!item.isFormField()) {
						pictureUrl = new File(item.getName()).getName();
						item.write(new File(UPLOAD_DIRECTORY + File.separator + pictureUrl));
					} else {
						System.out.println(item.getFieldName());
						if (item.getFieldName().equalsIgnoreCase("user-id")) {
							updateUserid = Integer.parseInt(item.getString());
							System.out.print("updateUserid "+updateUserid);
						}
						if (item.getFieldName().equals("fullname")) {
							userBean.setFname(item.getString());
						} else if (item.getFieldName().equals("userType")) {
							userBean.setUserType(item.getString());
						} else if (item.getFieldName().equals("username")) {
							userBean.setUname(item.getString());
						} else if (item.getFieldName().equals("email1")) {
							userBean.setEmail(item.getString());
						} else if (item.getFieldName().equals("cnic")) {
							userBean.setCnic(item.getString());
						} else if (item.getFieldName().equals("contact")) {
							userBean.setPhoneNo(item.getString());
						} else if (item.getFieldName().equals("gender")) {
							userBean.setGender(item.getString());
						} else if (item.getFieldName().equals("dob")) {
							String date = item.getString();
							SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
							java.util.Date dateStr = formatter.parse(date);
							java.sql.Date dateDB = new java.sql.Date(dateStr.getTime());
							System.out.print("Date" + dateDB);
							userBean.setBirthDate(dateDB);
						} else if (item.getFieldName().equals("address")) {
							userBean.setAddress(item.getString());
						} else if (item.getFieldName().equals("confirm_password1")) {
							userBean.setUpass(item.getString());
						}

					}
				}

				// File uploaded successfully
				request.setAttribute("message", "File Uploaded Successfully");
			} catch (Exception ex) {
				request.setAttribute("message", "File Upload Failed due to " + ex);
			}
			userBean.setPicture(pictureUrl);
			userBean.setCreatedAt(CurrentDate.getCurrentDate());
			userBean.setCreatedBy(user.getUserId());
			UserDao userDAO = new UserDaoImpl();
			if (updateUserid == 0) {
				userDAO.addUser(userBean);
			} else {
				userBean.setUserId(updateUserid);
				userDAO.updateUser(userBean);
			}
			response.sendRedirect("admin/view-users.jsp");

		} else {
			request.setAttribute("message", "Sorry this Servlet only handles file upload request");
		}

	}

}
