package com.geeks.dao;

import java.util.List;

import com.geeks.bean.BidBean;

public interface BidDao {

	public BidBean getBidById(Integer id);

	public Integer addBid(BidBean bb);

	public List<BidBean> getAllBids();

	public List<BidBean> getAllBidsByPropertyId(Integer id);

	public List<BidBean> getAllBidsByUserId(Integer id);

	public Integer updateBid(BidBean bb);

	public Integer deleteBid(Integer id);

}
