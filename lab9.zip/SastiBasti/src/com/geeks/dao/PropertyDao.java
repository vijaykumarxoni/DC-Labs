package com.geeks.dao;

import java.util.List;

import com.geeks.bean.PropertyBean;

public interface PropertyDao {

	public PropertyBean getPropertyById(Integer id);

	public Integer addProperty(PropertyBean pb);

	public List<PropertyBean> getAllProperties();

	public List<PropertyBean> getTenProperties();

	public List<PropertyBean> getTenSaleProperties();
	public List<PropertyBean> getTenRentProperties();

	public List<PropertyBean> getAllPropertiesByUserId(Integer id);

	public Integer getPropertyID(PropertyBean pb);

	public Integer updateProperty(PropertyBean pb);

	public Integer deleteProperty(Integer id);

}
