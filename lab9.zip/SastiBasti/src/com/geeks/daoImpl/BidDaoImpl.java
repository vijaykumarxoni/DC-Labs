package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.geeks.bean.BidBean;
import com.geeks.bean.LocationBean;
import com.geeks.bean.PropertyBean;
import com.geeks.bean.PropertyTypeBean;
import com.geeks.bean.UserBean;
import com.geeks.dao.BidDao;
import com.geeks.dao.PropertyDao;
import com.geeks.dao.UserDao;
import com.geeks.util.Dbcon;

public class BidDaoImpl implements BidDao {

	@Override
	public BidBean getBidById(Integer id) {

		BidBean bidBean = new BidBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM bid WHERE `bid_id`=? AND active=1";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {

				bidBean.setBidId(rs.getInt("bid_id"));
				UserDao userDao = new UserDaoImpl();
				PropertyDao propertyDao = new PropertyDaoImpl();
				bidBean.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				bidBean.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				bidBean.setbDate(rs.getInt("bdate"));
				bidBean.setAmount(rs.getDouble("amount"));
				bidBean.setName(rs.getString("name"));
				bidBean.setContact(rs.getString("contact"));
				bidBean.setDescription(rs.getString("description"));
				bidBean.setAward(rs.getString("award"));
				bidBean.setCreatedAt(rs.getDate("created_at"));
				bidBean.setUpdatedAt(rs.getDate("updated_by"));
				bidBean.setCreatedBy(rs.getInt("created_by"));
				bidBean.setUpdatedAt(rs.getDate("updated_at"));
				bidBean.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getBidById");
			e.printStackTrace();
		}
		return bidBean;

	}

	@Override
	public Integer addBid(BidBean bb) {

		int row = 0;
		String query = "INSERT INTO `bid`(user_id, property_id, bdate, amount, NAME, contact, `description`,`award`,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)";
		try {

			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, bb.getUserBean().getUserId());
			ps.setInt(2, bb.getPropertyBean().getPropertyId());
			ps.setInt(3, bb.getbDate());
			ps.setDouble(4, bb.getAmount());
			ps.setString(5, bb.getName());
			ps.setString(6, bb.getContact());
			ps.setString(7, bb.getDescription());
			ps.setString(8, bb.getAward());
			ps.setInt(9, bb.getCreatedBy());
			ps.setDate(10, bb.getCreatedAt());
			row = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in addBid");
			e.printStackTrace();
		}
		return row;

	}

	@Override
	public Integer updateBid(BidBean bb) {
		int i = 0;
		String query = " UPDATE bid SET user_id = ? , property_id = ? , bdate = ? , amount = ? , name = ? , contact = ? , description = ? , award = ? , updated_at = ?, updated_by=?  WHERE bid_id = ?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, bb.getUserBean().getUserId());
			ps.setInt(2, bb.getPropertyBean().getPropertyId());
			ps.setInt(3, bb.getbDate());
			ps.setDouble(4, bb.getAmount());
			ps.setString(5, bb.getName());
			ps.setString(6, bb.getContact());
			ps.setString(7, bb.getDescription());
			ps.setString(8, bb.getAward());
			ps.setDate(9, bb.getUpdatedAt());
			ps.setInt(10, bb.getUpdatedBy());
			ps.setInt(11, bb.getBidId());

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in updateBid");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public Integer deleteBid(Integer id) {
		int i = 0;
		String query = "UPDATE bid SET active=0 WHERE bid_id=? ";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in deleteBid");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<BidBean> getAllBidsByPropertyId(Integer id) {
		List<BidBean> bids = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM bid WHERE active=1 AND property_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				BidBean bidBean = new BidBean();
				bidBean.setBidId(rs.getInt("bid_id"));
				UserDao userDao = new UserDaoImpl();
				PropertyDao propertyDao = new PropertyDaoImpl();
				bidBean.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				bidBean.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				bidBean.setbDate(rs.getInt("bdate"));
				bidBean.setAmount(rs.getDouble("amount"));
				bidBean.setName(rs.getString("name"));
				bidBean.setContact(rs.getString("contact"));
				bidBean.setDescription(rs.getString("description"));
				bidBean.setAward(rs.getString("award"));
				bidBean.setCreatedAt(rs.getDate("created_at"));
				bidBean.setUpdatedBy(rs.getInt("updated_by"));
				bidBean.setCreatedBy(rs.getInt("created_by"));
				bidBean.setUpdatedAt(rs.getDate("updated_at"));
				bidBean.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getAllBidsByPropertyId");
			e.printStackTrace();
		}

		return bids;

	}

	@Override
	public List<BidBean> getAllBidsByUserId(Integer id) {
		List<BidBean> bids = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM bid WHERE active=1 AND user_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				BidBean bidBean = new BidBean();
				bidBean.setBidId(rs.getInt("bid_id"));
				UserDao userDao = new UserDaoImpl();
				PropertyDao propertyDao = new PropertyDaoImpl();
				bidBean.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				bidBean.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				bidBean.setbDate(rs.getInt("bdate"));
				bidBean.setAmount(rs.getDouble("amount"));
				bidBean.setName(rs.getString("name"));
				bidBean.setContact(rs.getString("contact"));
				bidBean.setDescription(rs.getString("description"));
				bidBean.setAward(rs.getString("award"));
				bidBean.setCreatedAt(rs.getDate("created_at"));
				bidBean.setUpdatedBy(rs.getInt("updated_by"));
				bidBean.setCreatedBy(rs.getInt("created_by"));
				bidBean.setUpdatedAt(rs.getDate("updated_at"));
				bidBean.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getAllBidsByUserId");
			e.printStackTrace();
		}

		return bids;

	}

	@Override
	public List<BidBean> getAllBids() {
		List<BidBean> bids = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM bid WHERE active=1";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				BidBean bidBean = new BidBean();
				bidBean.setBidId(rs.getInt("bid_id"));
				UserDao userDao = new UserDaoImpl();
				PropertyDao propertyDao = new PropertyDaoImpl();
				bidBean.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				bidBean.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				bidBean.setbDate(rs.getInt("bdate"));
				bidBean.setAmount(rs.getDouble("amount"));
				bidBean.setName(rs.getString("name"));
				bidBean.setContact(rs.getString("contact"));
				bidBean.setDescription(rs.getString("description"));
				bidBean.setAward(rs.getString("award"));
				bidBean.setCreatedAt(rs.getDate("created_at"));
				bidBean.setUpdatedBy(rs.getInt("updated_by"));
				bidBean.setCreatedBy(rs.getInt("created_by"));
				bidBean.setUpdatedAt(rs.getDate("updated_at"));
				bidBean.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getting Users");
			e.printStackTrace();
		}

		return bids;

	}

}
