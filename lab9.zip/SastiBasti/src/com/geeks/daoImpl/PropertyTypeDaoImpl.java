package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.geeks.bean.PropertyTypeBean;
import com.geeks.dao.PropertyTypeDao;
import com.geeks.util.Dbcon;

public class PropertyTypeDaoImpl implements PropertyTypeDao {

	@Override
	public PropertyTypeBean getPropertyTypeById(Integer id) {
		PropertyTypeBean ptb = new PropertyTypeBean();
		PreparedStatement ps=null;
		Connection con=null;
		try {
			 con = Dbcon.load();
			String query = "SELECT * FROM property_type WHERE  active=1 and property_type_id= ?; ";
			 ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				ptb.setPropertyTypeId(rs.getInt("property_type_id"));
				ptb.setPtype(rs.getString("ptype"));
				ptb.setCreatedAt(rs.getDate("created_at"));
				ptb.setUpdatedBy(rs.getInt("updated_by"));
				ptb.setCreatedBy(rs.getInt("created_by"));
				ptb.setUpdatedAt(rs.getDate("updated_at"));
				ptb.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getPropertyTypeById ");
			e.printStackTrace();
		}
	
		return ptb;

	}

	@Override
	public Integer addPropertyType(PropertyTypeBean ptb) {
		int row = 0;
		String query = "INSERT INTO property_type(`ptype`,created_by,created_at) VALUES (?,?,?)";
		try {

			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, ptb.getPtype());
			ps.setInt(2, ptb.getCreatedBy());
			ps.setDate(3, ptb.getCreatedAt());

			row = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in saving Bid");
			e.printStackTrace();
		}
		return row;

	}

	@Override
	public List<PropertyTypeBean> getAllPropertyTypes() {
		List<PropertyTypeBean> ptbs = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property_type WHERE active=1";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyTypeBean ptb = new PropertyTypeBean();
				ptb.setPropertyTypeId(rs.getInt("property_type_id"));
				ptb.setPtype(rs.getString("ptype"));
				ptb.setCreatedAt(rs.getDate("created_at"));
				ptb.setCreatedBy(rs.getInt("created_by"));
				ptb.setUpdatedAt(rs.getDate("updated_at"));
				ptb.setUpdatedBy(rs.getInt("updated_by"));
				
				ptb.setActive(rs.getInt("active"));
				ptbs.add(ptb);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllPropertyTypes");
			e.printStackTrace();
		}

		return ptbs;

	}

	@Override
	public Integer updatePropertyType(PropertyTypeBean ptb) {
		int i = 0;
		String query = " UPDATE `property_type` SET `ptype` = ? , `updated_by` = ? , `updated_at` = ?   WHERE `property_type_id` = ?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, ptb.getPtype());
			ps.setInt(2, ptb.getUpdatedBy());
			ps.setDate(3, ptb.getUpdatedAt());
			ps.setInt(4, ptb.getPropertyTypeId());

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in modification of User");
			e.printStackTrace();
		}
		return i;

	}

	@Override
	public Integer deletePropertyType(Integer id) {
		int i = 0;
		String query = "UPDATE property_type SET active=0 WHERE property_type_id=?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in deletePropertyType");
			e.printStackTrace();
		}
		return i;
	}

}
