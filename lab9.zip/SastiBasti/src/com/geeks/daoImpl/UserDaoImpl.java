package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.geeks.bean.UserBean;
import com.geeks.dao.UserDao;
import com.geeks.util.Dbcon;

public class UserDaoImpl implements UserDao {

	@Override
	public UserBean getUserById(Integer id) {

		UserBean user = new UserBean();

		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM USER WHERE active=1 AND user_id=? ";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				user.setUserId(rs.getInt("user_id"));
				user.setUname(rs.getString("uname"));
				user.setUpass(rs.getString("upass"));
				user.setFname(rs.getString("fname"));
				user.setEmail(rs.getString("email"));
				user.setCnic(rs.getString("cnic"));
				user.setPhoneNo(rs.getString("phone_no"));
				user.setBirthDate(rs.getDate("birth_date"));
				user.setAddress(rs.getString("address"));
				user.setPicture(rs.getString("picture"));
				user.setGender(rs.getString("gender"));
				user.setUserType(rs.getString("usertype"));
				user.setCreatedAt(rs.getDate("created_at"));
				user.setUpdatedBy(rs.getInt("updated_by"));
				user.setCreatedBy(rs.getInt("created_by"));
				user.setUpdatedAt(rs.getDate("updated_at"));
				user.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getUserById");
			e.printStackTrace();
		}
		return user;

	}

	@Override
	public Integer addUser(UserBean ub) {
		System.out.println("in save user");
		int i = 0;
		int counter = 0;
		String selectQuery = " SELECT * FROM USER WHERE (phone_no='" + ub.getPhoneNo() + "' OR uname='" + ub.getUname()
				+ "') and  active=1";

		String InsertQuery = " INSERT INTO USER (uname, upass, fname," + " email, cnic,phone_no,"
				+ "birth_date,address," + "picture,gender,usertype,"
				+ "created_at,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)  ";
		try {
			Connection con = Dbcon.load();

			PreparedStatement psSelect = con.prepareStatement(selectQuery);

			ResultSet rs = psSelect.executeQuery();
			while (rs.next()) {
				++counter;
			}

			if ((counter == 0)) {

				PreparedStatement ps = con.prepareStatement(InsertQuery);
				ps.setString(1, ub.getUname());
				ps.setString(2, ub.getUpass());
				ps.setString(3, ub.getFname());
				ps.setString(4, ub.getEmail());
				ps.setString(5, ub.getCnic());
				ps.setString(6, ub.getPhoneNo());
				ps.setDate(7, ub.getBirthDate());
				ps.setString(8, ub.getAddress());
				ps.setString(9, ub.getPicture());
				ps.setString(10, ub.getGender());
				ps.setString(11, ub.getUserType());
				ps.setDate(12, ub.getCreatedAt());
				ps.setInt(13, ub.getCreatedBy());

				i = ps.executeUpdate();
			} else {
				i = -1;
			}
		} catch (Exception e) {

			System.out.println("Error in addUser");
			e.printStackTrace();
		}
		System.out.println("iiii" + i);
		return i;

	}

	@Override
	public List<UserBean> getAllUsers() {

		List<UserBean> users = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM USER WHERE active=1";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				UserBean user = new UserBean();

				user.setUserId(rs.getInt("user_id"));
				user.setUname(rs.getString("uname"));
				user.setUpass(rs.getString("upass"));
				user.setFname(rs.getString("fname"));
				user.setEmail(rs.getString("email"));
				user.setCnic(rs.getString("cnic"));
				user.setPhoneNo(rs.getString("phone_no"));
				user.setBirthDate(rs.getDate("birth_date"));
				user.setAddress(rs.getString("address"));
				user.setPicture(rs.getString("picture"));
				user.setGender(rs.getString("gender"));
				user.setUserType(rs.getString("usertype"));
				user.setCreatedAt(rs.getDate("created_at"));
				user.setUpdatedBy(rs.getInt("updated_by"));
				user.setCreatedBy(rs.getInt("created_by"));
				user.setUpdatedAt(rs.getDate("updated_at"));
				user.setActive(rs.getInt("active"));
				users.add(user);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllUsers");
			e.printStackTrace();
		}

		return users;

	}

	@Override
	public Integer updateUser(UserBean ub) {
		int i = 0;
		String query = " UPDATE user SET uname = ?  , fname = ? , email = ? , cnic = ? , phone_no = ? , birth_date = ? , address = ? , picture = ?, gender=?,usertype=?, updated_at=? ,updated_by=?,  upass = ?  WHERE user_id = ?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, ub.getUname());
			ps.setString(2, ub.getFname());
			ps.setString(3, ub.getEmail());
			ps.setString(4, ub.getCnic());
			ps.setString(5, ub.getPhoneNo());
			ps.setDate(6, ub.getBirthDate());
			ps.setString(7, ub.getAddress());
			ps.setString(8, ub.getPicture());
			ps.setString(9, ub.getGender());
			ps.setString(10, ub.getUserType());
			ps.setDate(11, ub.getUpdatedAt());
			ps.setInt(12, ub.getUpdatedBy());
			ps.setString(13, ub.getUpass());
			ps.setInt(14, ub.getUserId());

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in updateUser");
			e.printStackTrace();
		}
		return i;

	}

	@Override
	public Integer deleteUser(Integer id) {
		int i = 0;
		String query = "UPDATE user SET active=0 WHERE `user_id` =? ";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in deleteUser");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public UserBean userLogin(String uname, String upass) {

		UserBean user = new UserBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM USER WHERE active=1 AND uname= ? AND upass=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, uname);
			ps.setString(2, upass);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				user.setUserId(rs.getInt("user_id"));
				user.setUname(rs.getString("uname"));
				user.setUpass(rs.getString("upass"));
				user.setFname(rs.getString("fname"));
				user.setEmail(rs.getString("email"));
				user.setCnic(rs.getString("cnic"));
				user.setPhoneNo(rs.getString("phone_no"));
				user.setBirthDate(rs.getDate("birth_date"));
				user.setAddress(rs.getString("address"));
				user.setPicture(rs.getString("picture"));
				user.setGender(rs.getString("gender"));
				user.setUserType(rs.getString("usertype"));
				user.setCreatedAt(rs.getDate("created_at"));
				user.setUpdatedBy(rs.getInt("updated_by"));
				user.setCreatedBy(rs.getInt("created_by"));
				user.setUpdatedAt(rs.getDate("updated_at"));
				user.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in userLogin");
			e.printStackTrace();
		}
		return user;

	}

}
