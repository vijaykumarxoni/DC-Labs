package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.geeks.bean.PropertyDetailBean;
import com.geeks.dao.PropertyDao;
import com.geeks.dao.PropertyDetailDao;
import com.geeks.util.Dbcon;

public class PropertyDetailDaoImpl implements PropertyDetailDao {

	@Override
	public PropertyDetailBean getPropertyDetailById(Integer id) {
		PropertyDetailBean pdb = new PropertyDetailBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM  property_detail WHERE property_detail_id=? AND active=1";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				pdb.setPropertyDetailId(rs.getInt("property_detail_id"));
				pdb.setPropertyDetailType(rs.getString("property_detail_type"));
				pdb.setPath(rs.getString("path"));
				pdb.setDetails(rs.getString("details"));
				PropertyDao propertyDao = new PropertyDaoImpl();
				pdb.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				pdb.setCreatedAt(rs.getDate("created_at"));
				pdb.setUpdatedAt(rs.getDate("updated_by"));
				pdb.setCreatedBy(rs.getInt("created_by"));
				pdb.setUpdatedAt(rs.getDate("updated_at"));
				pdb.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getPropertyDetailById");
			e.printStackTrace();
		}
		return pdb;

	}

	@Override
	public Integer addPropertyDetails(PropertyDetailBean pdb) {

		int row = 0;
		String query = "INSERT INTO `property_detail`(property_detail_type, path, details, property_id, created_by, created_at) VALUES (?,?,?,?,?,?)";
		try {

			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, pdb.getPropertyDetailType());
			ps.setString(2, pdb.getPath());
			ps.setString(3, pdb.getDetails());
			ps.setInt(4, pdb.getPropertyBean().getPropertyId());
			ps.setInt(5, pdb.getCreatedBy());
			ps.setDate(6, pdb.getCreatedAt());
			row = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error addPropertyDetails");
			e.printStackTrace();
		}
		return row;

	}

	@Override
	public List<PropertyDetailBean> getAllPropertyDetails() {
		List<PropertyDetailBean> pdbs = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM  property_detail WHERE active=1";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyDetailBean pdb = new PropertyDetailBean();
				pdb.setPropertyDetailId(rs.getInt("property_detail_id"));
				pdb.setPropertyDetailType(rs.getString("property_detail_type"));
				pdb.setPath(rs.getString("path"));
				pdb.setDetails(rs.getString("details"));
				PropertyDao propertyDao = new PropertyDaoImpl();
				pdb.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				pdb.setCreatedAt(rs.getDate("created_at"));
				pdb.setUpdatedAt(rs.getDate("updated_by"));
				pdb.setCreatedBy(rs.getInt("created_by"));
				pdb.setUpdatedAt(rs.getDate("updated_at"));
				pdb.setActive(rs.getInt("active"));
				pdbs.add(pdb);

			}
		} catch (Exception e) {
			System.out.println("Error in  PropertyDetails");
			e.printStackTrace();
		}

		return pdbs;

	}

	@Override
	public Integer updatePropertyDetail(PropertyDetailBean pdb) {
		int i = 0;
		String query = " UPDATE `property_detail` SET `property_detail_type` = ? , `path` = ? , `details` = ? , `property_id` = ? , `updated_by` = ? , `updated_at` = ?   WHERE `property_detail_id` = ?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, pdb.getPropertyDetailType());
			ps.setString(2, pdb.getPath());
			ps.setString(3, pdb.getDetails());
			ps.setInt(4, pdb.getPropertyBean().getPropertyId());
			ps.setInt(5, pdb.getUpdatedBy());
			ps.setDate(6, pdb.getUpdatedAt());
			ps.setInt(5, pdb.getPropertyDetailId());

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in updatePropertyDetail");
			e.printStackTrace();
		}
		return i;

	}

	@Override
	public Integer deletePropertyDetail(Integer id) {
		int i = 0;
		String query = "UPDATE property_detail SET active=0 WHERE property_detail_id=? ";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in updatePropertyDetail");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<PropertyDetailBean> getAllPropertyDetailsByPropertyId(Integer id) {

		List<PropertyDetailBean> pdbs = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM  property_detail WHERE active=1 AND `property_id`=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				PropertyDetailBean pdb = new PropertyDetailBean();
				pdb.setPropertyDetailId(rs.getInt("property_detail_id"));
				pdb.setPropertyDetailType(rs.getString("property_detail_type"));
				pdb.setPath(rs.getString("path"));
				pdb.setDetails(rs.getString("details"));
				PropertyDao propertyDao = new PropertyDaoImpl();
				pdb.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				pdb.setCreatedAt(rs.getDate("created_at"));
				pdb.setUpdatedAt(rs.getDate("updated_by"));
				pdb.setCreatedBy(rs.getInt("created_by"));
				pdb.setUpdatedAt(rs.getDate("updated_at"));
				pdb.setActive(rs.getInt("active"));
				pdbs.add(pdb);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllPropertyDetailsByPropertyId");
			e.printStackTrace();
		}

		return pdbs;

	}

	@Override
	public PropertyDetailBean getAllPropertyDetailByPropertyId(Integer id) {

		PropertyDetailBean pdb = new PropertyDetailBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM  property_detail WHERE active=1 AND `property_id`="+id+" ORDER BY `property_detail_id`  LIMIT 1";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				pdb.setPropertyDetailId(rs.getInt("property_detail_id"));
				pdb.setPropertyDetailType(rs.getString("property_detail_type"));
				pdb.setPath(rs.getString("path"));
				pdb.setDetails(rs.getString("details"));
				PropertyDao propertyDao = new PropertyDaoImpl();
				pdb.setPropertyBean(propertyDao.getPropertyById(rs.getInt("property_id")));
				pdb.setCreatedAt(rs.getDate("created_at"));
				pdb.setUpdatedAt(rs.getDate("updated_by"));
				pdb.setCreatedBy(rs.getInt("created_by"));
				pdb.setUpdatedAt(rs.getDate("updated_at"));
				pdb.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getAllPropertyDetailsByPropertyId");
			e.printStackTrace();
		}

		return pdb;

	}

}
