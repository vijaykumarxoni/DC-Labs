package com.geeks.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbcon {
	private static String url = "jdbc:mysql://localhost:3306/sastibasti_db";
    private static String user = "root";
    private static String password = "";
    public static Connection con;
    private Dbcon(){}
    public static Connection load() {
        if(con==null){
    	try {
        	Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url,user,password);
            System.out.println("DataBase Succesfully Loaded");

        } catch (Exception e) {

            System.out.println("Error in Load");
            e.printStackTrace();
        }

    }
    
    return con;
  
}
}