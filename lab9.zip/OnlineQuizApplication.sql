/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.6.21 : Database - online_quiz_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`online_quiz_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `online_quiz_db`;

/*Table structure for table `answers` */

DROP TABLE IF EXISTS `answers`;

CREATE TABLE `answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` varchar(1) DEFAULT NULL,
  `answer` varchar(255) DEFAULT NULL,
  `correct` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

/*Data for the table `answers` */

insert  into `answers`(`id`,`question_id`,`answer`,`correct`) values (1,'1','Ottawa',1),(2,'1','Toranto',0),(3,'1','Hamilton',0),(4,'1','Calgary',0),(5,'2','Mr Johnny',0),(6,'2','Mr. Donald Trump',1),(7,'2','Mr Obama',0),(8,'2','Johnson',0),(9,'3','India',0),(10,'3','China',0),(11,'3','Russia',1),(12,'3','USA',0),(13,'4','HTML',1),(14,'4','PHP',0),(15,'4','Java',0),(16,'4','ASP.net',0),(17,'5','a',1),(18,'5','jdj',0),(19,'5','jdjd',0),(20,'5','jdjd',0),(21,'6','Mobile programing',1),(22,'6','machine parts',0),(23,'6','microprocessor',0),(24,'6','Xyz',0),(25,'7','Frontend languagee',0),(26,'7','Backend lanaguuge',1),(27,'7','both',0),(28,'7','none',0),(29,'8','9.0',0),(30,'8','11.0',1),(31,'8','8.0',0),(32,'8','7.0',0),(33,'9','Mobile programing',1),(34,'9','a',0),(35,'9','b',0),(36,'9','c',0);

/*Table structure for table `attempt` */

DROP TABLE IF EXISTS `attempt`;

CREATE TABLE `attempt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `quiz_id` int(11) DEFAULT NULL,
  `correct_ans` int(11) DEFAULT NULL,
  `wrong_ans` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `attempt` */

insert  into `attempt`(`id`,`student_id`,`quiz_id`,`correct_ans`,`wrong_ans`) values (1,3,1,0,3),(2,7,3,1,2),(3,7,2,1,2);

/*Table structure for table `questions` */

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) DEFAULT NULL,
  `quiz_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

/*Data for the table `questions` */

insert  into `questions`(`id`,`question`,`quiz_id`) values (1,'capital of canada',1),(2,'Who is the current prime minister of USA?',1),(3,'Which is the biggest city of world?',1),(4,'Which lanaguage used for frontend ',2),(5,'What is java ee',2),(6,'what  is MP in programming',2),(7,'what is java',3),(8,'Java current version',3),(9,'what  is MP in programming',3);

/*Table structure for table `quiz` */

DROP TABLE IF EXISTS `quiz`;

CREATE TABLE `quiz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `quiz` */

insert  into `quiz`(`id`,`teacher_id`,`description`) values (1,2,'hellocji'),(2,5,'Java EE test'),(3,6,'Java Test');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `user_type` enum('Teacher','Student') DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`address`,`city`,`user_type`,`email`,`password`) values (3,'John','Toronto','Toronto','Student','john@gmail.com','john'),(5,'testTeacher','test','test','Teacher','test@gmail.com','test'),(6,'Alpha','alpha','alpha','Teacher','alpha@gmail.com','alpha'),(7,'testStudent','stud','zy','Student','stu@gmail.com','stu'),(8,'Vijay Kumar Soni','Hyd','Hyd','Student','vk@gmail.com','vkvk');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
