/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.6.21 : Database - sastibasti_db
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sastibasti_db` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sastibasti_db`;

/*Table structure for table `bid` */

DROP TABLE IF EXISTS `bid`;

CREATE TABLE `bid` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `bdate` datetime DEFAULT NULL,
  `amount` double(16,4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `award` enum('Yes','No') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`bid_id`),
  KEY `property_id` (`property_id`),
  CONSTRAINT `bid_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `bid` */

/*Table structure for table `location` */

DROP TABLE IF EXISTS `location`;

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_location` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `location` */

insert  into `location`(`location_id`,`parent_location`,`location`,`created_at`,`updated_at`,`created_by`,`updated_by`,`active`) values (1,NULL,'Sindh',NULL,NULL,NULL,NULL,1),(2,1,'Karachi',NULL,NULL,NULL,NULL,1),(3,1,'Hyderabad',NULL,NULL,NULL,NULL,1),(4,NULL,'Punjab',NULL,NULL,NULL,NULL,1),(5,4,'Lahore',NULL,NULL,NULL,NULL,1),(6,NULL,'Balouchistan',NULL,NULL,NULL,NULL,1),(7,NULL,'Gilgit Baltistan',NULL,NULL,NULL,NULL,1),(8,NULL,'Pakhtoon Khuwah (formerly NWFP)',NULL,NULL,NULL,NULL,1),(9,6,'Quetta',NULL,NULL,NULL,NULL,1),(10,7,'Gilgit',NULL,NULL,NULL,NULL,1),(11,8,'Peshawar',NULL,NULL,NULL,NULL,1);

/*Table structure for table `message` */

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) DEFAULT NULL,
  `message_to` int(11) DEFAULT NULL,
  `message_from` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `read` int(1) DEFAULT '1',
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`msg_id`),
  KEY `bid_id` (`bid_id`),
  CONSTRAINT `message_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `bid` (`bid_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `message` */

/*Table structure for table `property` */

DROP TABLE IF EXISTS `property`;

CREATE TABLE `property` (
  `property_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `property_tag` varchar(255) DEFAULT NULL,
  `longitude` double(16,6) DEFAULT NULL,
  `latitude` double(16,6) DEFAULT NULL,
  `property_type_id` int(11) DEFAULT NULL,
  `status` enum('Rent','Sale') DEFAULT NULL,
  `rooms` int(11) DEFAULT NULL,
  `drawing_room` enum('Yes','No') DEFAULT NULL,
  `total_area` double(16,4) DEFAULT NULL,
  `covered_area` double(16,4) DEFAULT NULL,
  `construction_date` date DEFAULT NULL,
  `price` double(16,4) DEFAULT NULL,
  `washroom` int(11) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`property_id`),
  KEY `user_id` (`user_id`),
  KEY `location_id` (`location_id`),
  CONSTRAINT `property_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `property_ibfk_2` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

/*Data for the table `property` */

insert  into `property`(`property_id`,`user_id`,`pname`,`address`,`property_tag`,`longitude`,`latitude`,`property_type_id`,`status`,`rooms`,`drawing_room`,`total_area`,`covered_area`,`construction_date`,`price`,`washroom`,`owner`,`location_id`,`created_by`,`updated_by`,`created_at`,`updated_at`,`active`) values (18,8,'Flat C13','Gul Center Hyd','Flat',81.356980,13.998070,6,'Sale',5,'Yes',1800.0000,1795.0000,'1995-04-01',350000.0000,5,'Vijay',3,8,NULL,'2019-04-06 00:00:00',NULL,1),(19,8,'Khan Bungalow','Bungalow # 234 near Mirchi 360 Defence Hyderbad','Bungalow,Hyderbad,Bungalow',81.356980,13.998070,3,'Sale',6,'Yes',4000.0000,3800.0000,'2010-02-17',9500000.0000,8,'Khan Kashif',3,8,NULL,'2019-04-06 00:00:00',NULL,1),(21,8,'Soni Mention','Gulshan Iqbal University Road Karachi ','House, Hyderabad',81.356980,13.998070,8,'Sale',4,'Yes',2800.0000,2600.0000,'2010-11-17',658400.0000,5,'Mr Asif Umer',2,8,NULL,'2019-04-06 00:00:00',NULL,1),(22,8,'Soni House','House # 231 Faisal Town Lahore','Ajay House, Lahore, House, Soni House',81.356980,13.998070,8,'Rent',2,'No',3500.0000,3200.0000,'2013-01-06',10000.0000,2,'Ajay',5,8,NULL,'2019-04-06 00:00:00',NULL,1);

/*Table structure for table `property_detail` */

DROP TABLE IF EXISTS `property_detail`;

CREATE TABLE `property_detail` (
  `property_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `property_detail_type` enum('Document','Image') DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `details` varchar(255) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`property_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

/*Data for the table `property_detail` */

insert  into `property_detail`(`property_detail_id`,`property_detail_type`,`path`,`details`,`property_id`,`created_by`,`updated_by`,`created_at`,`updated_at`,`active`) values (1,'Image','3y5q51wg.jpg','House Images',18,8,NULL,'2019-04-06 00:00:00',NULL,1),(2,'Image','006-Frot-Elevation-view-1-Kanal-Corner-House-With-Basement-DHA-Phase-5-Lahore-1200x800.jpg','House Images',18,8,NULL,'2019-04-06 00:00:00',NULL,1),(3,'Image','06e61d9fbf665c86a754fb948c84d9b0.jpg','House Images',18,8,NULL,'2019-04-06 00:00:00',NULL,1),(4,'Image','7b60c595324c083dd79a5ddcbfb189d7--pho-renovasi-rumah.jpg','House Images',18,8,NULL,'2019-04-06 00:00:00',NULL,1),(5,'Image','17.jpg','House Images',19,8,NULL,'2019-04-06 00:00:00',NULL,1),(6,'Image','cover.jpg','House Images',20,8,NULL,'2019-04-06 00:00:00',NULL,1),(7,'Image','elev.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(8,'Image','fae9a8c9a0bc45eccdf274829c3ea7c8.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(9,'Image','g-s-maylima-nagar-plot-22-in-urapakkam-elevation-photo-vhc.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(10,'Image','home-design-photos-punjab-modern-punjab-home-design-by-unique-architects-architects-unique.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(11,'Image','house_5_marla_near_lgs_school_adan_vali_4730074549461816883.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(12,'Image','house-elevation-design-front-for-duplex-in-indium-google-search-elev-good-more-information-3-storey-plan-indian-and-ground-floor-single-photo-kerala-double-g-2-bangalore.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(13,'Image','house-front-elevation-designs-for-single-floor-east-facing-newest-outstanding-house-designs-single-floor-front-elevation-of-house-front-elevation-designs-for-single-floor-east-facing.jpg','House Images',21,8,NULL,'2019-04-06 00:00:00',NULL,1),(14,'Image','1.jpg','House Images',22,8,NULL,'2019-04-06 00:00:00',NULL,1),(15,'Image','2.jpg','House Images',22,8,NULL,'2019-04-06 00:00:00',NULL,1);

/*Table structure for table `property_type` */

DROP TABLE IF EXISTS `property_type`;

CREATE TABLE `property_type` (
  `property_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `ptype` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`property_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `property_type` */

insert  into `property_type`(`property_type_id`,`ptype`,`created_by`,`updated_by`,`created_at`,`updated_at`,`active`) values (3,'Bungalows',8,8,'2019-03-26 22:03:19','2019-04-04 00:00:00',1),(4,'Apartments',8,8,'2019-03-26 22:12:13','2019-03-27 00:00:00',1),(5,'Cottage',8,NULL,'2019-03-26 22:12:51',NULL,1),(6,'Flat',8,NULL,'2019-03-26 22:14:21',NULL,1),(8,'Town House',8,NULL,'2019-03-27 00:00:00',NULL,1);

/*Table structure for table `rating` */

DROP TABLE IF EXISTS `rating`;

CREATE TABLE `rating` (
  `rating_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `rating` double(16,4) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`rating_id`),
  KEY `property_id` (`property_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `rating_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `property` (`property_id`),
  CONSTRAINT `rating_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `rating` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(255) DEFAULT NULL,
  `upass` varchar(255) DEFAULT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `cnic` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `gender` enum('Male','Female','Other') DEFAULT NULL,
  `usertype` enum('Admin','Other') DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`uname`,`upass`,`fname`,`email`,`cnic`,`phone_no`,`birth_date`,`address`,`picture`,`gender`,`usertype`,`created_at`,`updated_at`,`created_by`,`updated_by`,`active`) values (8,'Xoni','vksoni04','Vijay kumar Soni','vijay@zaptox.com','4410483831297','03313325691','1996-09-04','Sanghar, Sindh, Hyd','profile.jpg','Male','Admin','2019-02-23 00:00:00',NULL,1,NULL,1),(9,'Johny','john12','John','john@gmail.com','4444545454545455','03315999989','1996-09-02','Karachi','5e4d0ab735d883b53787fea263782568.jpg','Male','Other','2019-03-26 00:00:00',NULL,8,NULL,1),(13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,'2019-03-27 00:00:00',NULL,8,NULL,0),(14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,'2019-03-27 00:00:00',NULL,8,NULL,0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
