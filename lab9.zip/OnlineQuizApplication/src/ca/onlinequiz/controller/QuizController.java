package ca.onlinequiz.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.onlinequiz.beans.Answer;
import ca.onlinequiz.beans.Question;
import ca.onlinequiz.beans.Quiz;
import ca.onlinequiz.beans.User;
import ca.onlinequiz.dao.AnswerDAO;
import ca.onlinequiz.dao.QuestionDAO;
import ca.onlinequiz.dao.QuizDAO;

/**
 * Servlet implementation class QuizController
 */
@WebServlet("/QuizController")
public class QuizController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public QuizController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		if (request.getParameter("save_quiz") != null) {

			QuizDAO quizDAO = new QuizDAO();
			QuestionDAO questionDAO = new QuestionDAO();
			AnswerDAO answerDAO = new AnswerDAO();
			HttpSession session = request.getSession();
			User teacher = (User) session.getAttribute("user");
			System.out.print("session user:"+teacher.getName());
			Quiz quiz = new Quiz();
			String description = request.getParameter("description");
			quiz.setDescription(description);
			quiz.setTeacher(teacher);
			Quiz lastQuiz = quizDAO.saveQuiz(quiz);
			
			

			
			
			
			
			String quest1 = request.getParameter("question1");
			Question question1 = new Question();
			question1.setQuestion(quest1);
			question1.setQuiz(lastQuiz);
			Question lastQuestion1 = questionDAO.saveQuestion(question1);

			Answer answer11 = new Answer();
			Answer answer12 = new Answer();
			Answer answer13 = new Answer();
			Answer answer14 = new Answer();
			int correctAns1 = Integer.parseInt(request.getParameter("correct_ans1"));

			String opt11 = request.getParameter("opt11");
			answer11.setAnswer(opt11);
			answer11.setQuestion(lastQuestion1);
			String opt12 = request.getParameter("opt12");
			answer12.setAnswer(opt12);
			answer12.setQuestion(lastQuestion1);
			String opt13 = request.getParameter("opt13");
			answer13.setAnswer(opt13);
			answer13.setQuestion(lastQuestion1);
			String opt14 = request.getParameter("opt14");
			answer14.setAnswer(opt14);
			answer14.setQuestion(lastQuestion1);
			if(correctAns1==1){
				answer11.setCorrect(1);
			}
			else if(correctAns1==2){
				answer12.setCorrect(1);
			}
			else if(correctAns1==3){
				answer13.setCorrect(1);
			}else if(correctAns1==4){
				answer14.setCorrect(1);
			}
			answerDAO.saveAnswer(answer11);
			answerDAO.saveAnswer(answer12);
			answerDAO.saveAnswer(answer13);
			answerDAO.saveAnswer(answer14);
			

			
			
			String quest2 = request.getParameter("question2");
			Question question2 = new Question();
			question2.setQuestion(quest2);
			question2.setQuiz(lastQuiz);
			Question lastQuestion2 = questionDAO.saveQuestion(question2);

			Answer answer21 = new Answer();
			Answer answer22 = new Answer();
			Answer answer23 = new Answer();
			Answer answer24 = new Answer();
			int correctAns2 = Integer.parseInt(request.getParameter("correct_ans2"));

			String opt21 = request.getParameter("opt21");
			answer21.setAnswer(opt21);
			answer21.setQuestion(lastQuestion2);
			String opt22 = request.getParameter("opt22");
			answer22.setAnswer(opt22);
			answer22.setQuestion(lastQuestion2);
			String opt23 = request.getParameter("opt23");
			answer23.setAnswer(opt23);
			answer23.setQuestion(lastQuestion2);
			String opt24 = request.getParameter("opt24");
			answer24.setAnswer(opt24);
			answer24.setQuestion(lastQuestion2);
			if(correctAns2==1){
				answer21.setCorrect(1);
			}
			else if(correctAns2==2){
				answer22.setCorrect(1);
			}
			else if(correctAns2==3){
				answer23.setCorrect(1);
			}else if(correctAns2==4){
				answer24.setCorrect(1);
			}
			answerDAO.saveAnswer(answer21);
			answerDAO.saveAnswer(answer22);
			answerDAO.saveAnswer(answer23);
			answerDAO.saveAnswer(answer24);
			

			
			
			
			
			
			
			
			
			
			
			


			String quest3 = request.getParameter("question3");
			Question question3 = new Question();
			question3.setQuestion(quest3);
			question3.setQuiz(lastQuiz);
			Question lastQuestion3 = questionDAO.saveQuestion(question3);

			Answer answer31 = new Answer();
			Answer answer32 = new Answer();
			Answer answer33 = new Answer();
			Answer answer34 = new Answer();
			int correctAns3 = Integer.parseInt(request.getParameter("correct_ans3"));

			String opt31 = request.getParameter("opt31");
			answer31.setAnswer(opt31);
			answer31.setQuestion(lastQuestion3);
			String opt32 = request.getParameter("opt32");
			answer32.setAnswer(opt32);
			answer32.setQuestion(lastQuestion3);
			String opt33 = request.getParameter("opt33");
			answer33.setAnswer(opt33);
			answer33.setQuestion(lastQuestion3);
			String opt34 = request.getParameter("opt34");
			answer34.setAnswer(opt34);
			answer34.setQuestion(lastQuestion3);
			if(correctAns3==1){
				answer31.setCorrect(1);
			}
			else if(correctAns3==2){
				answer32.setCorrect(1);
			}
			else if(correctAns3==3){
				answer33.setCorrect(1);
			}else if(correctAns3==4){
				answer34.setCorrect(1);
			}
			answerDAO.saveAnswer(answer31);
			answerDAO.saveAnswer(answer32);
			answerDAO.saveAnswer(answer33);
			answerDAO.saveAnswer(answer34);

			response.sendRedirect("welcome.jsp");
			


		}

	}

}
