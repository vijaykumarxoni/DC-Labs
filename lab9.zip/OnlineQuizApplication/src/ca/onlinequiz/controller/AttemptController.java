package ca.onlinequiz.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.onlinequiz.beans.Answer;
import ca.onlinequiz.beans.Attempt;
import ca.onlinequiz.beans.Question;
import ca.onlinequiz.beans.Quiz;
import ca.onlinequiz.beans.User;
import ca.onlinequiz.dao.AttemptDAO;
import ca.onlinequiz.dao.AnswerDAO;
import ca.onlinequiz.dao.QuestionDAO;
import ca.onlinequiz.dao.QuizDAO;

/**
 * Servlet implementation class AttemptController
 */
@WebServlet("/AttemptController")
public class AttemptController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AttemptController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
if(request.getParameter("save_quiz")!=null){
	AnswerDAO answerDAO=new AnswerDAO();
	AttemptDAO attemptDAO=new AttemptDAO(); 
	QuizDAO quizDAO=new QuizDAO();
	HttpSession session=request.getSession();
	User student=(User)session.getAttribute("user");
	int correct=0,wrong=3;
	
	int quizId=Integer.parseInt(request.getParameter("quizId"));
	Quiz quiz=quizDAO.getQuiz(quizId);
	int selectAnswer1=Integer.parseInt(request.getParameter("selectAnswer1"));
	Answer answer1=answerDAO.getAnswer(selectAnswer1);	
	
	
	if(answer1.getCorrect()==1){
		correct++;
		wrong--;
	}
	
	
	int selectAnswer2=Integer.parseInt(request.getParameter("selectAnswer2"));
	Answer answer2=answerDAO.getAnswer(selectAnswer2);	

	if(answer2.getCorrect()==1){
		correct++;
		wrong--;
	}
	int selectAnswer3=Integer.parseInt(request.getParameter("selectAnswer3"));
	Answer answer3=answerDAO.getAnswer(selectAnswer3);	


	if(answer3.getCorrect()==1){
		correct++;
		wrong--;
	}

	Attempt attempt=new Attempt();
	attempt.setCorrectAnswers(correct);
	attempt.setWrongAnswers(wrong);
	attempt.setStudent(student);
	attempt.setQuiz(quiz);

	attemptDAO.saveAttempt(attempt);
	response.sendRedirect("welcome-student.jsp");
	
	

	
}
	
	}

}
