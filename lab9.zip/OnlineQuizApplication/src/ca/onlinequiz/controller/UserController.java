package ca.onlinequiz.controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ca.onlinequiz.beans.User;
import ca.onlinequiz.dao.UserDAO;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
	if(request.getParameter("logout")!=null){
		HttpSession session=request.getSession();
		session.invalidate();
		response.sendRedirect("login.jsp");
	}
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		UserDAO userDAO = new UserDAO();

		if (request.getParameter("save") != null) {
			User user = new User();
			String userType = request.getParameter("userType");
			String name = request.getParameter("name");
			String address = request.getParameter("address");
			String city = request.getParameter("city");
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			user.setName(name);
			user.setAddress(address);
			user.setCity(city);
			user.setEmail(email);
			user.setPassword(password);
			user.setUserType(userType);
			userDAO.registerUser(user);

			perfromLogin(request, response, email, password);

		}

		else if (request.getParameter("submit") != null) {
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			User user = userDAO.userLogin(email, password);
			perfromLogin(request, response, email, password);

		}

	}

	public void perfromLogin(HttpServletRequest request, HttpServletResponse response, String email, String password) {
		HttpSession session = request.getSession();

		UserDAO userDAO = new UserDAO();
		User user = userDAO.userLogin(email, password);
		session.setAttribute("user", user);

		if (user.getUserType().equalsIgnoreCase("Teacher")) {
			try {
				response.sendRedirect("welcome.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {

			try {
				response.sendRedirect("welcome-student.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
