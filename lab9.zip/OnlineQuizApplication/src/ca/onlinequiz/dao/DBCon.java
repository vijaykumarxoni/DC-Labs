package ca.onlinequiz.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBCon {
	private static String url = "jdbc:mysql://localhost:3306/online_quiz_db";
	private static String user = "root";
	private static String password = "";
	public static Connection con;

	private DBCon() {
	}

	public static Connection load() {
		if (con == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection(url, user, password);

			} catch (Exception e) {

				e.printStackTrace();
			}

		}

		return con;

	}
}