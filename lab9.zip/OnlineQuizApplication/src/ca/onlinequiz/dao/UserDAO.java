package ca.onlinequiz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.jdbc.Connection;

import ca.onlinequiz.beans.User;

public class UserDAO {

	public User userLogin(String email, String password) {

		User user = new User();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM USER WHERE email=? AND PASSWORD=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				user.setUserId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAddress(rs.getString("address"));
				user.setCity(rs.getString("city"));
				user.setUserType(rs.getString("user_type"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;

	}

	public void registerUser(User user) {

		String InsertQuery = " INSERT INTO user (name, address, city, user_type, email,password) VALUES (?,?,?,?,?,?)";
		try {
			Connection con = (Connection) DBCon.load();

			PreparedStatement ps = con.prepareStatement(InsertQuery);
			ps.setString(1, user.getName());
			ps.setString(2, user.getAddress());
			ps.setString(3, user.getCity());
			ps.setString(4, user.getUserType());
			ps.setString(5, user.getEmail());
			ps.setString(6, user.getPassword());

			ps.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	
	public User getUser(int id) {

		User user = new User();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM USER WHERE id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				user.setUserId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setAddress(rs.getString("address"));
				user.setCity(rs.getString("city"));
				user.setUserType(rs.getString("user_type"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;

	}


}
