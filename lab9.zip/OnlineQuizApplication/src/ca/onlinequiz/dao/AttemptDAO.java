package ca.onlinequiz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import ca.onlinequiz.beans.Answer;
import ca.onlinequiz.beans.Attempt;

public class AttemptDAO {

	public void saveAttempt(Attempt attempt) {

		String InsertQuery = " INSERT INTO attempt (student_id, quiz_id,correct_ans,wrong_ans) VALUES (?,?,?,?)";
		try {
			Connection con = (Connection) DBCon.load();

			PreparedStatement ps = con.prepareStatement(InsertQuery);

			ps.setInt(1, attempt.getStudent().getUserId());
			ps.setInt(2, attempt.getQuiz().getQuizId());
			ps.setInt(3, attempt.getCorrectAnswers());
			ps.setInt(4, attempt.getWrongAnswers());

			ps.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public List<Attempt> getAttemptsByStudentId(int id) {
		List<Attempt> attempts = new ArrayList<Attempt>();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM attempt WHERE student_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserDAO userDAO = new UserDAO();
				QuizDAO quizDAO = new QuizDAO();
				Attempt attempt = new Attempt();
				attempt.setAttemptId(rs.getInt("id"));
				attempt.setQuiz(quizDAO.getQuiz(rs.getInt("quiz_id")));
				attempt.setStudent(userDAO.getUser(rs.getInt("student_id")));
				attempt.setWrongAnswers(rs.getInt("wrong_ans"));
				attempt.setCorrectAnswers(rs.getInt("correct_ans"));
				attempts.add(attempt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return attempts;

	}
	public List<Attempt> getAttemptsByQuizId(int id) {
		List<Attempt> attempts = new ArrayList<Attempt>();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM attempt WHERE quiz_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserDAO userDAO = new UserDAO();
				QuizDAO quizDAO = new QuizDAO();
				Attempt attempt = new Attempt();
				attempt.setAttemptId(rs.getInt("id"));
				attempt.setQuiz(quizDAO.getQuiz(rs.getInt("quiz_id")));
				attempt.setStudent(userDAO.getUser(rs.getInt("student_id")));
				attempt.setWrongAnswers(rs.getInt("wrong_ans"));
				attempt.setCorrectAnswers(rs.getInt("correct_ans"));
				attempts.add(attempt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return attempts;

	}

}
