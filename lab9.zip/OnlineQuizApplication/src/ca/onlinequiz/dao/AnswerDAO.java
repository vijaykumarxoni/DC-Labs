package ca.onlinequiz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import ca.onlinequiz.beans.Answer;
import ca.onlinequiz.beans.Question;

public class AnswerDAO {

	public void saveAnswer(Answer answer) {

		String InsertQuery = " INSERT INTO answers (question_id, answer,correct) VALUES (?,?,?)";
		try {
			Connection con = (Connection) DBCon.load();

			PreparedStatement ps = con.prepareStatement(InsertQuery);
		
			ps.setInt(1, answer.getQuestion().getQuestionId());
			ps.setString(2, answer.getAnswer());
			ps.setInt(3, answer.getCorrect());

			ps.executeUpdate();

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public List<Answer> getAnswerByQuestionID(int id) {
		List<Answer> answers = new ArrayList<Answer>();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM answers WHERE question_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				QuestionDAO questionDAO = new QuestionDAO();
				Answer answer = new Answer();
				answer.setAnswerId(rs.getInt("id"));
				answer.setQuestion(questionDAO.getQustion(rs.getInt("question_id")));
				answer.setAnswer(rs.getString("answer"));
				answer.setCorrect(rs.getInt("correct"));
				answers.add(answer);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return answers;

	}
	
	public Answer getAnswer(int id) {
		Answer answer = new Answer();

		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM answers WHERE id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				QuestionDAO questionDAO = new QuestionDAO();
				answer.setAnswerId(rs.getInt("id"));
				answer.setQuestion(questionDAO.getQustion(rs.getInt("question_id")));
				answer.setAnswer(rs.getString("answer"));
				answer.setCorrect(rs.getInt("correct"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return answer;

	}
}
