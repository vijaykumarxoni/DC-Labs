package ca.onlinequiz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.fabric.xmlrpc.base.Array;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

import ca.onlinequiz.beans.Quiz;
import ca.onlinequiz.beans.User;

public class QuizDAO {

	public Quiz saveQuiz(Quiz quiz) {
		Quiz insertedQuiz = null;
		String insertQuery = "INSERT INTO `online_quiz_db`.`quiz` (`teacher_id`, `description`) VALUES ("+quiz.getTeacher().getUserId()+",'"+quiz.getDescription()+"')";
		try {
			Connection con = (Connection) DBCon.load();

			PreparedStatement ps = con.prepareStatement(insertQuery);
			ps.executeUpdate();
			insertedQuiz = getLastAddedQuizByTeacher(quiz.getTeacher().getUserId());

		} catch (Exception e) {

			e.printStackTrace();
		}
		return insertedQuiz;

	}

	public List<Quiz> getQuizzesByTeacherId(int id) {
		List<Quiz> quizzes = new ArrayList<Quiz>();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM quiz WHERE teacher_id=? order by id desc";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserDAO userDAO = new UserDAO();
				Quiz quiz = new Quiz();
				quiz.setQuizId(rs.getInt("id"));
				quiz.setTeacher(userDAO.getUser(rs.getInt("teacher_id")));
				quiz.setDescription(rs.getString("description"));
				quizzes.add(quiz);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return quizzes;

	}
	
	
	public List<Quiz> getQuizzes() {
		List<Quiz> quizzes = new ArrayList<Quiz>();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM quiz  order by id desc";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserDAO userDAO = new UserDAO();
				Quiz quiz = new Quiz();
				quiz.setQuizId(rs.getInt("id"));
				quiz.setTeacher(userDAO.getUser(rs.getInt("teacher_id")));
				quiz.setDescription(rs.getString("description"));
				quizzes.add(quiz);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return quizzes;

	}


	public Quiz getQuiz(int id) {
		Quiz quiz = new Quiz();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM quiz WHERE id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserDAO userDAO = new UserDAO();
				quiz.setQuizId(rs.getInt("id"));
				quiz.setTeacher(userDAO.getUser(rs.getInt("teacher_id")));
				quiz.setDescription(rs.getString("description"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return quiz;

	}

	public Quiz getLastAddedQuizByTeacher(int id) {
		Quiz quiz = new Quiz();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM quiz WHERE `teacher_id`=? ORDER BY id DESC LIMIT 1 ";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				UserDAO userDAO = new UserDAO();
				quiz.setQuizId(rs.getInt("id"));
				quiz.setTeacher(userDAO.getUser(rs.getInt("teacher_id")));
				quiz.setDescription(rs.getString("description"));			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return quiz;

	}
}
