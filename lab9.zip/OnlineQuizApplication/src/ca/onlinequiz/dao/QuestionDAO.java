package ca.onlinequiz.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;

import ca.onlinequiz.beans.Question;
import ca.onlinequiz.beans.Quiz;

public class QuestionDAO {

	public Question saveQuestion(Question question) {
		Question insertedQuiz = null;
		String InsertQuery = " INSERT INTO questions (question, quiz_id) VALUES (?,?)";
		try {
			Connection con = (Connection) DBCon.load();

			PreparedStatement ps = con.prepareStatement(InsertQuery);
			ps.setString(1, question.getQuestion());
			ps.setInt(2, question.getQuiz().getQuizId());
			ps.executeUpdate();
			insertedQuiz = getLastAddedQuestionByQuiz(question.getQuiz().getQuizId());

		} catch (Exception e) {

			e.printStackTrace();
		}
		return insertedQuiz;
	}

	public List<Question> getQustionsByQuizID(int id) {
		List<Question> questions = new ArrayList<Question>();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM questions WHERE quiz_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				QuizDAO quizDAO = new QuizDAO();
				Question question = new Question();
				question.setQuestionId(rs.getInt("id"));
				question.setQuestion(rs.getString("question"));
				question.setQuiz(quizDAO.getQuiz(rs.getInt("quiz_id")));
				questions.add(question);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return questions;

	}

	public Question getQustion(int id) {
		Question question = new Question();

		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM questions WHERE id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				QuizDAO quizDAO = new QuizDAO();
				question.setQuestionId(rs.getInt("id"));
				question.setQuestion(rs.getString("question"));
				question.setQuiz(quizDAO.getQuiz(rs.getInt("quiz_id")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return question;

	}
	public Question getLastAddedQuestionByQuiz(int id) {
	    Question question=new Question();
		try {
			Connection con = (Connection) DBCon.load();
			String query = "SELECT * FROM questions WHERE quiz_id=?  ORDER BY id DESC LIMIT 1";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				QuizDAO quizDAO = new QuizDAO();
				question.setQuestionId(rs.getInt("id"));
				question.setQuestion(rs.getString("question"));
				question.setQuiz(quizDAO.getQuiz(rs.getInt("quiz_id")));			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return question;

	}
}
