import java.net.*;

public class Sender {

	public static void main(String [] arg){
		if(arg.length == 5){
			try{
			InetAddress inetAddress1 = InetAddress.getByName(arg[0]);
			int port1 = Integer.parseInt(arg[1]);
			InetAddress inetAddress2 = InetAddress.getByName(arg[2]);
			int port2 = Integer.parseInt(arg[3]);
			String message = arg[4];

            
			DatagramSocket datagramSocket = new DatagramSocket();
			byte [] bytes = message.getBytes();

			DatagramPacket datagramPacket1 = new DatagramPacket(bytes,bytes.length,inetAddress1,port1);
			DatagramPacket datagramPacket2 = new DatagramPacket(bytes,bytes.length,inetAddress2,port2);
			
			

			datagramSocket.send(datagramPacket1);
			datagramSocket.send(datagramPacket2);

			datagramSocket.close();
	
			}
			catch (Exception e) {
				
			}


		}
		else{
			System.out.println("Require command line arguments");
		}
	}
}