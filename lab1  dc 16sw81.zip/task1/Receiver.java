import java.net.*;
import java.io.*;

 class Receiver {

	public static void main(String [] arg){
		if(arg.length != 1){
		System.out.println("Kindly enter require num of command line args");
		}
		else{

			int port = Integer.parseInt(arg[0]);
			int MAX_LEN = 1024;
			for (int i=1;i<=6 ; i++) {
			try{

			DatagramSocket datagramSocket = new DatagramSocket(port);
			byte [] bytes= new byte[MAX_LEN];

			DatagramPacket datagramPacket = new DatagramPacket(bytes,bytes.length);
			

			datagramSocket.receive(datagramPacket);
			String msg = new String(bytes);
			System.out.println(msg);
			Thread.sleep(4000);
			datagramSocket.close();
	
			}
			catch (Exception e) {
				
			}


		}
	}
	}
}