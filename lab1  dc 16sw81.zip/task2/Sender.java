import java.net.*;

public class Sender {

	public static void main(String [] arg){
		if(arg.length >= 3){
			try{
			InetAddress inetAddress = InetAddress.getByName(arg[0]);
			int port = Integer.parseInt(arg[1]);
			String message = arg[2];

            
			DatagramSocket DS = new DatagramSocket();
			byte [] B = message.getBytes();

			DatagramPacket DP = new DatagramPacket(B,B.length,inetAddress,port);
			

			DS.send(DP);
			DS.close();
	
			}
			catch (Exception e) {
				
			}


		}
		else{
			System.out.println("Require command line arguments");
		}
	}
}