package com.geeks.bean;

import java.io.Serializable;
import java.sql.Date;

public class PropertyBean extends Bean implements Serializable {

	private Integer propertyId;
	private UserBean userBean;
	private String pname;
	private String address;
	private String propertyTag;
	private double longitude;
	private double latitude;
	private PropertyTypeBean propertyTypeBean;
	private String status;
	private Integer rooms;
	private String drawingRoom;
	private double totalArea;
	private double coveredArea;
	private Date constructionDate;
	private double price;
	private Integer washrooms;
	private String owner;
	private LocationBean locationBean;

	public PropertyBean() {

	}

	public Integer getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPropertyTag() {
		return propertyTag;
	}

	public void setPropertyTag(String propertyTag) {
		this.propertyTag = propertyTag;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public PropertyTypeBean getPropertyTypeBean() {
		return propertyTypeBean;
	}

	public void setPropertyTypeBean(PropertyTypeBean propertyTypeBean) {
		this.propertyTypeBean = propertyTypeBean;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getRooms() {
		return rooms;
	}

	public void setRooms(Integer rooms) {
		this.rooms = rooms;
	}


	public String getDrawingRoom() {
		return drawingRoom;
	}

	public void setDrawingRoom(String drawingRoom) {
		this.drawingRoom = drawingRoom;
	}

	public double getTotalArea() {
		return totalArea;
	}

	public void setTotalArea(double totalArea) {
		this.totalArea = totalArea;
	}

	public double getCoveredArea() {
		return coveredArea;
	}

	public void setCoveredArea(double coveredArea) {
		this.coveredArea = coveredArea;
	}

	public Date getConstructionDate() {
		return constructionDate;
	}

	public void setConstructionDate(Date constructionDate) {
		this.constructionDate = constructionDate;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Integer getWashrooms() {
		return washrooms;
	}

	public void setWashrooms(Integer washrooms) {
		this.washrooms = washrooms;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public LocationBean getLocationBean() {
		return locationBean;
	}

	public void setLocationBean(LocationBean locationBean) {
		this.locationBean = locationBean;
	}

	@Override
	public String toString() {
		return "PropertyBean [propertyId=" + propertyId + ", userBean=" + userBean + ", pname=" + pname + ", address="
				+ address + ", propertyTag=" + propertyTag + ", longitude=" + longitude + ", latitude=" + latitude
				+ ", propertyTypeBean=" + propertyTypeBean + ", status=" + status + ", rooms=" + rooms
				+ ", drawingRoom=" + drawingRoom + ", totalArea=" + totalArea + ", coveredArea=" + coveredArea
				+ ", constructionDate=" + constructionDate + ", price=" + price + ", washrooms=" + washrooms
				+ ", owner=" + owner + ", locationBean=" + locationBean + "]";
	}

}
