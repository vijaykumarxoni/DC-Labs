package com.geeks.bean;

import java.io.Serializable;
import java.sql.Date;

public class MessageBean extends Bean implements Serializable {
	private Integer msgId;
	private BidBean bidBean;
	private UserBean msgTo;
	private UserBean msgFrom;
	private Date msgDate;
	private Integer read;
	private String description;

	public MessageBean() {
	}

	public Integer getMsgId() {
		return msgId;
	}

	public void setMsgId(Integer msgId) {
		this.msgId = msgId;
	}

	public BidBean getBidBean() {
		return bidBean;
	}

	public void setBidBean(BidBean bidBean) {
		this.bidBean = bidBean;
	}

	public UserBean getMsgTo() {
		return msgTo;
	}

	public void setMsgTo(UserBean msgTo) {
		this.msgTo = msgTo;
	}

	public UserBean getMsgFrom() {
		return msgFrom;
	}

	public void setMsgFrom(UserBean msgFrom) {
		this.msgFrom = msgFrom;
	}

	public Date getMsgDate() {
		return msgDate;
	}

	public void setMsgDate(Date msgDate) {
		this.msgDate = msgDate;
	}

	public Integer getRead() {
		return read;
	}

	public void setRead(Integer read) {
		this.read = read;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "MessageBean [msgId=" + msgId + ", bidBean=" + bidBean + ", msgTo=" + msgTo + ", msgFrom=" + msgFrom
				+ ", msgDate=" + msgDate + ", read=" + read + ", description=" + description + "]";
	}

}
