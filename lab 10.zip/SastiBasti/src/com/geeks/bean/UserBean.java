package com.geeks.bean;

import java.io.Serializable;
import java.sql.Date;

public class UserBean extends Bean implements  {

	private Integer userId;
	private String uname;
	private String upass;
	private String fname;
	private String email;
	private String cnic;
	private String phoneNo;
	private Date birthDate;
	private String address;
	private String picture;
	private String gender;
	private String userType;

	public UserBean() {
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpass() {
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCnic() {
		return cnic;
	}

	public void setCnic(String cnic) {
		this.cnic = cnic;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	@Override
	public String toString() {
		return "UserBean [userId=" + userId + ", uname=" + uname + ", upass=" + upass + ", fname=" + fname + ", email="
				+ email + ", cnic=" + cnic + ", phoneNo=" + phoneNo + ", birthDate=" + birthDate + ", address="
				+ address + ", picture=" + picture + ", gender=" + gender + ", userType=" + userType + "]";
	}

}
