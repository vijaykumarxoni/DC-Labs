package com.geeks.bean;

import java.io.Serializable;

public class BidBean extends Bean implements Serializable {

	private Integer bidId;
	private UserBean userBean;
	private PropertyBean propertyBean;
	private Integer bDate;
	private double amount;
	private String name;
	private String contact;
	private String description;
	private String award;

	public BidBean() {
	}

	public Integer getBidId() {
		return bidId;
	}

	public void setBidId(Integer bidId) {
		this.bidId = bidId;
	}

	public UserBean getUserBean() {
		return userBean;
	}

	public void setUserBean(UserBean userBean) {
		this.userBean = userBean;
	}

	public PropertyBean getPropertyBean() {
		return propertyBean;
	}

	public void setPropertyBean(PropertyBean propertyBean) {
		this.propertyBean = propertyBean;
	}

	public Integer getbDate() {
		return bDate;
	}

	public void setbDate(Integer bDate) {
		this.bDate = bDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAward() {
		return award;
	}

	public void setAward(String award) {
		this.award = award;
	}

	@Override
	public String toString() {
		return "BidBean [bidId=" + bidId + ", userBean=" + userBean + ", propertyBean=" + propertyBean + ", bDate="
				+ bDate + ", amount=" + amount + ", name=" + name + ", contact=" + contact + ", description="
				+ description + ", award=" + award + "]";
	}

}
