package com.geeks.business;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.jni.Local;

import com.geeks.bean.LocationBean;
import com.geeks.bean.PropertyBean;
import com.geeks.bean.PropertyDetailBean;
import com.geeks.bean.PropertyTypeBean;
import com.geeks.bean.UserBean;
import com.geeks.dao.LocationDao;
import com.geeks.dao.PropertyDao;
import com.geeks.dao.PropertyDetailDao;
import com.geeks.daoImpl.LocationDaoImpl;
import com.geeks.daoImpl.PropertyDaoImpl;
import com.geeks.daoImpl.PropertyDetailDaoImpl;
import com.geeks.util.CurrentDate;

/**
 * Servlet implementation class PropertyServlet
 */
@WebServlet("/PropertyServlet")
public class PropertyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PropertyServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter pw=response.getWriter();
	     String action=request.getParameter("action");
//	    
	     if(action.equals("getSubLocs")){
	    	 Integer parentId=Integer.parseInt(request.getParameter("parentId"));
	    	 LocationDao locationDao=new LocationDaoImpl();
	    	 List<LocationBean>subLocs=locationDao.getAllSubLocsByParentId(parentId);
	    	 pw.write("<select   style='background: #fbfbfe;border: 1px solid #ccc;'  required  title='Sub - Location' name='subLocation'>");
	    	 for(LocationBean lb:subLocs){
	    		 pw.write("<option value='" + lb.getLocationId() + "'>" + lb.getLocation() + "</option>");
	    	 }
	    	 pw.write("</select>");
	     }
//	     else if(action.equals("getRentProperties")){
//				pw.write("<div class='row'>");
//				pw.write("<div class='col-md-12'>");
//						pw.write("<div class='property-tab-menu'>");
//								pw.write("<ul class='nav' role='tablist'>");
//					pw.write("			<li role='presentation' class='active'><a href='#sale' id='showSale'");
//												pw.write("aria-controls='sale' data-toggle='tab'>PROPERTY FOR SALE</a></li>");
//														pw.write("	<li role='presentation'><a href='#rent' id='showRent'");
//																pw.write("	aria-controls='rent' data-toggle='tab'>PROPERTY TO RENT</a></li>");
//																		pw.write("</ul>");
//																				pw.write("</div>");
//																						pw.write("	</div>");
//																								pw.write("</div>");
//																										pw.write("		<div class='row'>");
//																												pw.write("		<div class='tab-content'>");
//																														pw.write("	<div role='tabpanel' class='tab-pane active' id='sale'>");
//																																pw.write("						<div class='property-list'>");
//
//
//								PropertyDao propertyDao = new PropertyDaoImpl();
//								PropertyDetailDao propertyDetailDao = new PropertyDetailDaoImpl();
//								List<PropertyBean> properties = propertyDao.getTenRentProperties();
//								for (PropertyBean pb : properties) {
//									PropertyDetailBean pdb = propertyDetailDao.getAllPropertyDetailByPropertyId(pb.getPropertyId());
//
//
//									pw.write("	<div class='col-md-4'>");
//											pw.write("		<div class='single-property'>");
//												if(pb.getStatus().equalsIgnoreCase("Rent")) 
//													pw.write("<span class='bg-blue'>FOR Rent</span>");
//								    else{
//								    	pw.write("<span>FOR SALE</span>");	
//								    }
//								    
//								    
//
//
//									pw.write("<div class='property-img'>");
//									pw.write("	<a href='Property-Detail-Page.jsp?propertyId='"+pb.getPropertyId()+"> <img");
//									pw.write("	src='${pageContext.request.contextPath}/image/"+pdb.getPath()+"'height='300px' alt=''>");
//											pw.write("	</a>");
//													pw.write("		</div>");
//															pw.write("		<div class='property-desc'>");
//																	pw.write("<div class='property-desc-top'>");
//																			pw.write("	<h6>");
//																					pw.write("		<a href='Property-Detail-Page.jsp?propertyId="+pb.getPropertyId()+">"+pb.getPname()+"</a>");
//																					pw.write("	</h6>");
//																							pw.write("	<h4 class='price'>Rs "+(int)pb.getPrice()+"</h4>");
//																									pw.write("	<div class='property-location'>");
//																											pw.write("		<p>");
//																													pw.write("	<img src='img/property/icon-5.png' alt=''>");
//																															pb.getLocationBean().getLocation();
//																																	pw.write("	</p>");
//																																			pw.write("	</div>");
//																																					pw.write("</div>");
//																																							pw.write("	<div class='property-desc-bottom'>");
//																																									pw.write("		<div class='property-bottom-list'>");
//																																											pw.write("	<ul>");
//																																													pw.write("	<li><img src='img/property/icon-1.png' alt=''>");
//														pw.write("<span>"+pb.getTotalArea()+" sqft</span></li>");
//														pw.write("		<li><img src='img/property/icon-2.png' alt=''>");
//																pw.write("			<span><%=pb.getRooms() %></span></li>");
//																		pw.write("		<li><img src='img/property/icon-3.png' alt=''>");
//																				pw.write("		<span>pb.getWashrooms() </span></li>");
//															
//																						pw.write("</ul></div></div></div></div></div>");
//											
//										
//									
//									
//							
//
//
//
//
//							} 
//					pw.write("</div></div></div></div>");
//					
//				
			
	     
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getParameter("action");
		if (action.equals("addProperty")) {
			PropertyDao propertyDao = new PropertyDaoImpl();
			PropertyBean pb = new PropertyBean();
			pb.setPname("" + request.getParameter("pname"));
			pb.setAddress(request.getParameter("address"));
			pb.setWashrooms(Integer.parseInt(request.getParameter("bathrooms")));
			UserBean ub = new UserBean();
			ub.setUserId(8);
			pb.setUserBean(ub);
			pb.setTotalArea(Double.parseDouble(request.getParameter("totalArea")));
			pb.setStatus(request.getParameter("status"));
			pb.setRooms(Integer.parseInt(request.getParameter("bedrooms")));
			PropertyTypeBean pType = new PropertyTypeBean();
			pType.setPropertyTypeId(Integer.parseInt(request.getParameter("pType")));
			pb.setPropertyTypeBean(pType);
			pb.setPropertyTag(request.getParameter("propertyTags"));
			pb.setPrice(Double.parseDouble(request.getParameter("propertyPrice")));
			pb.setOwner(request.getParameter("owner"));
			pb.setLongitude(81.35698);
			LocationBean lb = new LocationBean();
			lb.setLocationId(Integer.parseInt(request.getParameter("subLocation")));
			pb.setLocationBean(lb);
			pb.setLatitude(13.99807);
			pb.setDrawingRoom(request.getParameter("drawingRoom"));
			pb.setCreatedBy(8);
			pb.setCreatedAt(CurrentDate.getCurrentDate());
			pb.setCoveredArea(Double.parseDouble(request.getParameter("coveredArea")));
			pb.setConstructionDate(Date.valueOf(request.getParameter("constructionDate")));
			int i = propertyDao.addProperty(pb);
			if (i != 0) {
				int propertyId = propertyDao.getPropertyID(pb);
				response.sendRedirect("frontend/add-property-images.jsp?propertyId=" + propertyId);
			}

		}
	}

}
