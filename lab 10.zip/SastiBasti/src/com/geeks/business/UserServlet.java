package com.geeks.business;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.geeks.bean.UserBean;
import com.geeks.dao.UserDao;
import com.geeks.daoImpl.UserDaoImpl;
import com.google.gson.Gson;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();

		PrintWriter pw = response.getWriter();
		Gson gson = new Gson();
		UserDao userDao = new UserDaoImpl();

		pw.write(gson.toJson(userDao.getAllUsers()));

		if (request.getParameter("sign-out") != null) {
			session.invalidate();
			response.sendRedirect("admin/login-page.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserDao userDao = new UserDaoImpl();


		if (request.getParameter("delete_user_id") != null) {
			Integer id=Integer.parseInt(request.getParameter("delete_user_id"));
            userDao.deleteUser(id);
			response.sendRedirect("admin/view-users.jsp");

		}

		if (request.getParameter("login") != null) {
			UserBean userBean = null;
			PrintWriter pw = response.getWriter();
			String uname = request.getParameter("uname");
			String upass = request.getParameter("upass");
			userBean = userDao.userLogin(uname, upass);
			if (userBean.getUserId() == null) {
				pw.write("Login Failed!");
				response.sendRedirect("admin/login-page.jsp?error=1");

			} else {
				if (userBean.getUserType().equalsIgnoreCase("Admin")) {
					pw.write("Login Sucessfully!");
					session.setAttribute("user", userBean);
					response.sendRedirect("admin/home-page.jsp");
				}

			}
		}
	}

}
