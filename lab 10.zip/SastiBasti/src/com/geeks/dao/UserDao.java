package com.geeks.dao;

import java.util.ArrayList;
import java.util.List;

import com.geeks.bean.UserBean;


public interface UserDao {


	public UserBean userLogin(String uname,String upass);

	public UserBean getUserById(Integer id);

    public Integer addUser(UserBean ub);

    public List<UserBean> getAllUsers();

    public Integer updateUser(UserBean ub);

    public Integer deleteUser(Integer id);
	
	
}
