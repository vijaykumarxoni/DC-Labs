package com.geeks.dao;

import java.util.List;

import com.geeks.bean.BidBean;
import com.geeks.bean.PropertyTypeBean;

public interface PropertyTypeDao {

	public PropertyTypeBean getPropertyTypeById(Integer id);

	public Integer addPropertyType(PropertyTypeBean ptb);

	public List<PropertyTypeBean> getAllPropertyTypes();

	public Integer updatePropertyType(PropertyTypeBean ptb);

	public Integer deletePropertyType(Integer id);

}
