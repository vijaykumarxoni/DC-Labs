package com.geeks.dao;

import java.util.List;

import com.geeks.bean.MessageBean;

public interface MessageDao {

	public MessageBean getMsgById(Integer id);

	public Integer addMsg(MessageBean mb);

	public List<MessageBean> getAllMsg();

	public List<MessageBean> getAllMsgByBidId(Integer id);

	public List<MessageBean> getAllMsgByUserId(Integer id);

	public Integer updateMsg(MessageBean mb);

	public Integer deleteMsg(Integer id);
}
