package com.geeks.dao;

import java.util.List;

import com.geeks.bean.LocationBean;

public interface LocationDao {

	public LocationBean getLocationById(Integer id);

	public Integer addLocation(LocationBean lb);

	public List<LocationBean> getAllLocations();
	public List<LocationBean> getAllParentLocs();
	public List<LocationBean> getAllSubLocsByParentId(Integer parentId);
	public Integer updateLocation(LocationBean lb);

	public Integer deleteLocation(Integer id);

}
