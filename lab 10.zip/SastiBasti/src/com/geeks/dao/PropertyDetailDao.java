package com.geeks.dao;

import java.util.List;

import com.geeks.bean.PropertyDetailBean;

public interface PropertyDetailDao {

	public PropertyDetailBean getPropertyDetailById(Integer id);

	public Integer addPropertyDetails(PropertyDetailBean pdb);

	public List<PropertyDetailBean> getAllPropertyDetails();

	public List<PropertyDetailBean> getAllPropertyDetailsByPropertyId(Integer id);

	public Integer updatePropertyDetail(PropertyDetailBean pdb);

	public Integer deletePropertyDetail(Integer id);
	
	PropertyDetailBean getAllPropertyDetailByPropertyId(Integer id);

}
