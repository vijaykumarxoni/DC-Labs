package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.geeks.bean.LocationBean;
import com.geeks.bean.PropertyBean;
import com.geeks.dao.LocationDao;
import com.geeks.dao.PropertyTypeDao;
import com.geeks.dao.UserDao;
import com.geeks.util.Dbcon;

public class LocationDaoImpl implements LocationDao {

	@Override
	public LocationBean getLocationById(Integer id) {
		// TODO Auto-generated method stub
		LocationBean lb = new LocationBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM location WHERE active=1 AND location_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				lb.setLocation(rs.getString("location"));
                lb.setParentLocation(rs.getInt("parent_location"));
				lb.setLocationId(rs.getInt("location_id"));
				lb.setCreatedAt(rs.getDate("created_at"));
				lb.setUpdatedBy(rs.getInt("updated_by"));
				lb.setCreatedBy(rs.getInt("created_by"));
				lb.setUpdatedAt(rs.getDate("updated_at"));
				lb.setActive(rs.getInt("active"));
		
			}
		} catch (Exception e) {
			System.out.println("Error in getLocationById");
			e.printStackTrace();
		}

		return lb;

	}

	@Override
	public Integer addLocation(LocationBean lb) {
		int row = 0;
		String query = "INSERT INTO  location(parent_location, location,created_by,created_at) VALUES (?,?,?,?)";
		try {

			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, lb.getParentLocation());
			ps.setString(2, lb.getLocation());
			ps.setInt(3, lb.getCreatedBy());
			ps.setDate(4, lb.getCreatedAt());

			row = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in addLocation");
			e.printStackTrace();
		}
		return row;

	}

	@Override
	public List<LocationBean> getAllLocations() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer updateLocation(LocationBean lb) {
		int i = 0;
		String query = " UPDATE location SET parent_location = ? , location= ?  updated_at = ?, updated_by=?  WHERE location_id = ?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, lb.getParentLocation());
			ps.setString(2, lb.getLocation());
			ps.setDate(3, lb.getUpdatedAt());
			ps.setInt(4, lb.getUpdatedBy());
			ps.setInt(5, lb.getLocationId());

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in updateLocation");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public Integer deleteLocation(Integer id) {
		int i = 0;
		String query = "UPDATE location SET active=0 WHERE location_id=? ";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in deleteLocation");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<LocationBean> getAllParentLocs() {
		List<LocationBean> locs = new ArrayList<LocationBean>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM location WHERE parent_location IS NULL AND active=1";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				LocationBean lb=new LocationBean();
				lb.setLocation(rs.getString("location"));
				lb.setLocationId(rs.getInt("location_id"));
				lb.setCreatedAt(rs.getDate("created_at"));
				lb.setUpdatedBy(rs.getInt("updated_by"));
				lb.setCreatedBy(rs.getInt("created_by"));
				lb.setUpdatedAt(rs.getDate("updated_at"));
				lb.setActive(rs.getInt("active"));
		        locs.add(lb);
				
			}
		} catch (Exception e) {
			System.out.println("Error in getAllParentLocs");
			e.printStackTrace();
		}
		return locs;

	}

	@Override
	public List<LocationBean> getAllSubLocsByParentId(Integer parentId) {
		List<LocationBean> locs = new ArrayList<LocationBean>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM location WHERE  active=1 AND parent_location=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, parentId);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				LocationBean lb=new LocationBean();
				lb.setLocation(rs.getString("location"));
                lb.setParentLocation(rs.getInt("parent_location"));
				lb.setLocationId(rs.getInt("location_id"));
				lb.setCreatedAt(rs.getDate("created_at"));
				lb.setUpdatedBy(rs.getInt("updated_by"));
				lb.setCreatedBy(rs.getInt("created_by"));
				lb.setUpdatedAt(rs.getDate("updated_at"));
				lb.setActive(rs.getInt("active"));
		        locs.add(lb);
				 
			}
		} catch (Exception e) {
			System.out.println("Error in getAllSubLocsByParentId");
			e.printStackTrace();
		}
		return locs;

	}

}
