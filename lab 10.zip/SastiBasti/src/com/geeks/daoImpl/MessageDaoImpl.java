package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.geeks.bean.BidBean;
import com.geeks.bean.MessageBean;
import com.geeks.dao.BidDao;
import com.geeks.dao.MessageDao;
import com.geeks.dao.PropertyDao;
import com.geeks.dao.UserDao;
import com.geeks.util.Dbcon;

public class MessageDaoImpl implements MessageDao {

	@Override
	public MessageBean getMsgById(Integer id) {

		MessageBean msgBean = new MessageBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM message WHERE msg_id=? AND active=1";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				msgBean.setMsgId(rs.getInt("msg_id"));
				BidDao bidDao = new BidDaoImpl();
				UserDao userDao = new UserDaoImpl();
				msgBean.setBidBean(bidDao.getBidById(rs.getInt("bid_id")));
				msgBean.setMsgTo(userDao.getUserById(rs.getInt("message_to")));
				msgBean.setMsgFrom(userDao.getUserById(rs.getInt("message_from")));
				msgBean.setMsgDate(rs.getDate("date"));
				msgBean.setRead(rs.getInt("READ"));
				msgBean.setDescription(rs.getString("description"));
				msgBean.setCreatedAt(rs.getDate("created_at"));
				msgBean.setUpdatedAt(rs.getDate("updated_by"));
				msgBean.setCreatedBy(rs.getInt("created_by"));
				msgBean.setUpdatedAt(rs.getDate("updated_at"));
				msgBean.setActive(rs.getInt("active"));

			}
		} catch (Exception e) {
			System.out.println("Error in getMsgById");
			e.printStackTrace();
		}
		return msgBean;

	}

	@Override
	public Integer addMsg(MessageBean mb) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MessageBean> getAllMsg() {
		List<MessageBean> msgs = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM bid WHERE active=1 ";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				MessageBean msgBean = new MessageBean();
				msgBean.setMsgId(rs.getInt("msg_id"));
				BidDao bidDao = new BidDaoImpl();
				UserDao userDao = new UserDaoImpl();
				msgBean.setBidBean(bidDao.getBidById(rs.getInt("bid_id")));
				msgBean.setMsgTo(userDao.getUserById(rs.getInt("message_to")));
				msgBean.setMsgFrom(userDao.getUserById(rs.getInt("message_from")));
				msgBean.setMsgDate(rs.getDate("date"));
				msgBean.setRead(rs.getInt("READ"));
				msgBean.setDescription(rs.getString("description"));
				msgBean.setCreatedAt(rs.getDate("created_at"));
				msgBean.setUpdatedAt(rs.getDate("updated_by"));
				msgBean.setCreatedBy(rs.getInt("created_by"));
				msgBean.setUpdatedAt(rs.getDate("updated_at"));
				msgBean.setActive(rs.getInt("active"));
				msgs.add(msgBean);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllBidsByPropertyId");
			e.printStackTrace();
		}

		return msgs;

	}


	@Override
	public List<MessageBean> getAllMsgByUserId(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer updateMsg(MessageBean mb) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer deleteMsg(Integer id) {
		int i = 0;
		String query = "UPDATE message SET active=0 WHERE msg_id=?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in deleteBid");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<MessageBean> getAllMsgByBidId(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

}
