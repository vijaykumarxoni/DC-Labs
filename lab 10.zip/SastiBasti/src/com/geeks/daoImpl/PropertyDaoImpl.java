package com.geeks.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.geeks.bean.LocationBean;
import com.geeks.bean.PropertyBean;
import com.geeks.bean.PropertyTypeBean;
import com.geeks.bean.RatingBean;
import com.geeks.bean.UserBean;
import com.geeks.dao.LocationDao;
import com.geeks.dao.PropertyDao;
import com.geeks.dao.PropertyTypeDao;
import com.geeks.dao.UserDao;
import com.geeks.util.Dbcon;

import sun.security.action.GetBooleanAction;

public class PropertyDaoImpl implements PropertyDao {

	@Override
	public PropertyBean getPropertyById(Integer id) {

		PropertyBean property = new PropertyBean();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property WHERE active=1 and property_id= "+id;
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {

				property.setPropertyId(rs.getInt("property_id"));
				UserDao userDao = new UserDaoImpl();
				property.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				PropertyTypeDao propertyTypeDao = new PropertyTypeDaoImpl();
				property.setPropertyTypeBean(propertyTypeDao.getPropertyTypeById(rs.getInt("property_type_id")));
				property.setPname(rs.getString("pname"));
				property.setAddress(rs.getString("address"));
				property.setPropertyTag(rs.getString("property_tag"));
				property.setLongitude(rs.getDouble("longitude"));
				property.setLatitude(rs.getDouble("latitude"));
				property.setStatus(rs.getString("STATUS"));
				property.setRooms(rs.getInt("Rooms"));
				property.setDrawingRoom(rs.getString("drawing_room"));
				property.setTotalArea(rs.getDouble("total_area"));
				property.setCoveredArea(rs.getDouble("covered_area"));
				property.setConstructionDate(rs.getDate("construction_date"));
				property.setPrice(rs.getDouble("price"));
				property.setWashrooms(rs.getInt("washroom"));
				property.setOwner(rs.getString("OWNER"));
				property.setCreatedAt(rs.getDate("created_at"));
				property.setUpdatedBy(rs.getInt("updated_by"));
				property.setCreatedBy(rs.getInt("created_by"));
				property.setUpdatedAt(rs.getDate("updated_at"));
				property.setActive(rs.getInt("active"));
				LocationDao locationDao = new LocationDaoImpl();
				property.setLocationBean(locationDao.getLocationById(rs.getInt("location_id")));

			}
		} catch (Exception e) {
			System.out.println("Error in getPropertyById");
			e.printStackTrace();
		}
		return property;
	}

	@Override
	public Integer addProperty(PropertyBean pb) {
		// TODO Auto-generated method stub
		int row = 0;
		String query = "INSERT INTO property(user_id, pname, address," + "property_tag,longitude,latitude,"
				+ "property_type_id," + " status,Rooms,drawing_room,total_area,covered_area,construction_date"
				+ ",price,washroom,owner,location_id,created_by,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
		try {

			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, pb.getUserBean().getUserId());
			ps.setString(2, pb.getPname());
			ps.setString(3, pb.getAddress());
			ps.setString(4, pb.getPropertyTag());
			ps.setDouble(5, pb.getLongitude());
			ps.setDouble(6, pb.getLatitude());
			ps.setInt(7, pb.getPropertyTypeBean().getPropertyTypeId());
			ps.setString(8, pb.getStatus());
			ps.setInt(9, pb.getRooms());
			ps.setString(10, pb.getDrawingRoom());
			ps.setDouble(11, pb.getTotalArea());
			ps.setDouble(12, pb.getCoveredArea());
			ps.setDate(13, pb.getConstructionDate());
			ps.setDouble(14, pb.getPrice());
			ps.setInt(15, pb.getWashrooms());
			ps.setString(16, pb.getOwner());
			ps.setInt(17, pb.getLocationBean().getLocationId());
			ps.setInt(18, pb.getCreatedBy());
			ps.setDate(19, pb.getCreatedAt());
			row = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in addProperty");
			e.printStackTrace();
		}
		return row;

	}

	@Override
	public List<PropertyBean> getAllProperties() {

		List<PropertyBean> properties = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property WHERE active=1";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyBean property = new PropertyBean();

				property.setPropertyId(rs.getInt("property_id"));

				// userbean

				property.setPropertyId(rs.getInt("property_id"));
				// userbean
				UserDao userDao = new UserDaoImpl();
				property.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				PropertyTypeDao propertyTypeDao = new PropertyTypeDaoImpl();
				property.setPropertyTypeBean(propertyTypeDao.getPropertyTypeById(rs.getInt("property_type_id")));
				property.setPname(rs.getString("pname"));
				property.setAddress(rs.getString("address"));
				property.setPropertyTag(rs.getString("property_tag"));
				property.setLongitude(rs.getDouble("longitude"));
				property.setLatitude(rs.getDouble("latitude"));
				property.setStatus(rs.getString("STATUS"));
				property.setRooms(rs.getInt("rooms"));
				property.setDrawingRoom(rs.getString("drawing_room"));
				property.setTotalArea(rs.getDouble("total_area"));
				property.setCoveredArea(rs.getDouble("covered_area"));
				property.setConstructionDate(rs.getDate("construction_date"));
				property.setPrice(rs.getDouble("price"));
				property.setWashrooms(rs.getInt("washroom"));
				property.setOwner(rs.getString("OWNER"));
				property.setCreatedAt(rs.getDate("created_at"));
				property.setUpdatedBy(rs.getInt("updated_by"));
				property.setCreatedBy(rs.getInt("created_by"));
				property.setUpdatedAt(rs.getDate("updated_at"));
				property.setActive(rs.getInt("active"));
				LocationDao locationDao = new LocationDaoImpl();
				property.setLocationBean(locationDao.getLocationById(rs.getInt("location_id")));
				properties.add(property);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllProperties");
			e.printStackTrace();
		}

		return properties;

	}

	@Override
	public Integer updateProperty(PropertyBean pb) {

		int i = 0;
		String query = "UPDATE property SET user_id = ? , pname = ? , address = ? , property_tag = ? , longitude = ? , latitude = ? , property_type_id = ? , STATUS = ? , rooms = ?, drawing_room=?,total_area=? , covered_area=? , construction_date=?, price=?, washroom=?, OWNER=?, location_id=?, updated_by=?, updated_at=? WHERE property_id = ?";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, pb.getUserBean().getUserId());
			ps.setString(2, pb.getPname());
			ps.setString(3, pb.getAddress());
			ps.setString(4, pb.getPropertyTag());
			ps.setDouble(5, pb.getLongitude());
			ps.setDouble(6, pb.getLatitude());
			ps.setInt(7, pb.getPropertyTypeBean().getPropertyTypeId());
			ps.setString(8, pb.getStatus());
			ps.setInt(9, pb.getRooms());
			ps.setDouble(11, pb.getTotalArea());
			ps.setDouble(12, pb.getCoveredArea());
			ps.setDate(13, pb.getConstructionDate());
			ps.setDouble(14, pb.getPrice());
			ps.setInt(15, pb.getWashrooms());
			ps.setString(16, pb.getOwner());
			ps.setInt(17, pb.getLocationBean().getLocationId());
			ps.setInt(18, pb.getUpdatedBy());
			ps.setDate(19, pb.getUpdatedAt());
			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in updateProperty");
			e.printStackTrace();
		}
		return i;

	}

	@Override
	public Integer deleteProperty(Integer id) {

		int i = 0;
		String query = "UPDATE property SET active=0 WHERE property_id=? ";
		try {
			Connection con = Dbcon.load();
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);

			i = ps.executeUpdate();
		} catch (Exception e) {

			System.out.println("Error in deleteProperty");
			e.printStackTrace();
		}
		return i;
	}

	@Override
	public List<PropertyBean> getAllPropertiesByUserId(Integer id) {
		List<PropertyBean> properties = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property WHERE active=1 AND user_id=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyBean property = new PropertyBean();
				property.setPropertyId(rs.getInt("property_id"));
				property.setPropertyId(rs.getInt("property_id"));
				UserDao userDao = new UserDaoImpl();
				property.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				PropertyTypeDao propertyTypeDao = new PropertyTypeDaoImpl();
				property.setPropertyTypeBean(propertyTypeDao.getPropertyTypeById(rs.getInt("property_type_id")));
				property.setPname(rs.getString("pname"));
				property.setAddress(rs.getString("address"));
				property.setPropertyTag(rs.getString("property_tag"));
				property.setLongitude(rs.getDouble("longitude"));
				property.setLatitude(rs.getDouble("latitude"));
				property.setStatus(rs.getString("STATUS"));
				property.setRooms(rs.getInt("rooms"));
				property.setDrawingRoom(rs.getString("drawing_room"));
				property.setTotalArea(rs.getDouble("total_area"));
				property.setCoveredArea(rs.getDouble("covered_area"));
				property.setConstructionDate(rs.getDate("construction_date"));
				property.setPrice(rs.getDouble("price"));
				property.setWashrooms(rs.getInt("washroom"));
				property.setOwner(rs.getString("OWNER"));
				property.setCreatedAt(rs.getDate("created_at"));
				property.setUpdatedBy(rs.getInt("updated_by"));
				property.setCreatedBy(rs.getInt("created_by"));
				property.setUpdatedAt(rs.getDate("updated_at"));
				property.setActive(rs.getInt("active"));
				LocationDao locationDao = new LocationDaoImpl();
//				property.setLocationBean(locationDao.getLocationById(rs.getInt("location_id")));
				properties.add(property);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllPropertiesByUserId");
			e.printStackTrace();
		}

		return properties;

	}

	@Override
	public Integer getPropertyID(PropertyBean pb) {
		int propertyId = 0;
		try {
			Connection con = Dbcon.load();
			String query = "SELECT `property_id` FROM property WHERE user_id="+pb.getUserBean().getUserId()+" AND pname='"+pb.getPname()+"' AND total_area="+pb.getTotalArea()+" AND rooms="+pb.getRooms()+" AND construction_date='"+pb.getConstructionDate()+"' ORDER BY property_id DESC LIMIT 1";
			PreparedStatement ps = con.prepareStatement(query);
//			ps.setInt(1, pb.getUserBean().getUserId());
//			ps.setString(2, pb.getPname());
//			ps.setDouble(3, pb.getTotalArea());
//			ps.setInt(4, pb.getRooms());
//			ps.setDate(5, pb.getConstructionDate());
			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {

				propertyId = rs.getInt("property_id");

			}
		} catch (Exception e) {
			System.out.println("Error in getPropertyID");
			e.printStackTrace();
		}
		return propertyId;

	}

	@Override
	public List<PropertyBean> getTenProperties() {
		List<PropertyBean> properties = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property WHERE active=1 ORDER BY property_id DESC LIMIT 10";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyBean property = new PropertyBean();

				property.setPropertyId(rs.getInt("property_id"));

				// userbean

				property.setPropertyId(rs.getInt("property_id"));
				// userbean
				UserDao userDao = new UserDaoImpl();
				property.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				PropertyTypeDao propertyTypeDao = new PropertyTypeDaoImpl();
				property.setPropertyTypeBean(propertyTypeDao.getPropertyTypeById(rs.getInt("property_type_id")));
				property.setPname(rs.getString("pname"));
				property.setAddress(rs.getString("address"));
				property.setPropertyTag(rs.getString("property_tag"));
				property.setLongitude(rs.getDouble("longitude"));
				property.setLatitude(rs.getDouble("latitude"));
				property.setStatus(rs.getString("STATUS"));
				property.setRooms(rs.getInt("rooms"));
				property.setDrawingRoom(rs.getString("drawing_room"));
				property.setTotalArea(rs.getDouble("total_area"));
				property.setCoveredArea(rs.getDouble("covered_area"));
				property.setConstructionDate(rs.getDate("construction_date"));
				property.setPrice(rs.getDouble("price"));
				property.setWashrooms(rs.getInt("washroom"));
				property.setOwner(rs.getString("OWNER"));
				property.setCreatedAt(rs.getDate("created_at"));
				property.setUpdatedBy(rs.getInt("updated_by"));
				property.setCreatedBy(rs.getInt("created_by"));
				property.setUpdatedAt(rs.getDate("updated_at"));
				property.setActive(rs.getInt("active"));
				LocationDao locationDao = new LocationDaoImpl();
				property.setLocationBean(locationDao.getLocationById(rs.getInt("location_id")));
				properties.add(property);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllProperties");
			e.printStackTrace();
		}

		return properties;

	}

	@Override
	public List<PropertyBean> getTenSaleProperties() {
		List<PropertyBean> properties = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property WHERE active=1 AND STATUS='Sale' ORDER BY property_id DESC LIMIT 10";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyBean property = new PropertyBean();

				property.setPropertyId(rs.getInt("property_id"));

				// userbean

				property.setPropertyId(rs.getInt("property_id"));
				// userbean
				UserDao userDao = new UserDaoImpl();
				property.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				PropertyTypeDao propertyTypeDao = new PropertyTypeDaoImpl();
				property.setPropertyTypeBean(propertyTypeDao.getPropertyTypeById(rs.getInt("property_type_id")));
				property.setPname(rs.getString("pname"));
				property.setAddress(rs.getString("address"));
				property.setPropertyTag(rs.getString("property_tag"));
				property.setLongitude(rs.getDouble("longitude"));
				property.setLatitude(rs.getDouble("latitude"));
				property.setStatus(rs.getString("STATUS"));
				property.setRooms(rs.getInt("rooms"));
				property.setDrawingRoom(rs.getString("drawing_room"));
				property.setTotalArea(rs.getDouble("total_area"));
				property.setCoveredArea(rs.getDouble("covered_area"));
				property.setConstructionDate(rs.getDate("construction_date"));
				property.setPrice(rs.getDouble("price"));
				property.setWashrooms(rs.getInt("washroom"));
				property.setOwner(rs.getString("OWNER"));
				property.setCreatedAt(rs.getDate("created_at"));
				property.setUpdatedBy(rs.getInt("updated_by"));
				property.setCreatedBy(rs.getInt("created_by"));
				property.setUpdatedAt(rs.getDate("updated_at"));
				property.setActive(rs.getInt("active"));
				LocationDao locationDao = new LocationDaoImpl();
				property.setLocationBean(locationDao.getLocationById(rs.getInt("location_id")));
				properties.add(property);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllProperties");
			e.printStackTrace();
		}

		return properties;

	}

	@Override
	public List<PropertyBean> getTenRentProperties() {
		List<PropertyBean> properties = new ArrayList<>();
		try {
			Connection con = Dbcon.load();
			String query = "SELECT * FROM property WHERE active=1 AND STATUS='Rent' ORDER BY property_id DESC LIMIT 10";
			PreparedStatement ps = con.prepareStatement(query);

			ResultSet rs = ps.executeQuery(query);
			while (rs.next()) {
				PropertyBean property = new PropertyBean();

				property.setPropertyId(rs.getInt("property_id"));

				// userbean

				property.setPropertyId(rs.getInt("property_id"));
				// userbean
				UserDao userDao = new UserDaoImpl();
				property.setUserBean(userDao.getUserById(rs.getInt("user_id")));
				PropertyTypeDao propertyTypeDao = new PropertyTypeDaoImpl();
				property.setPropertyTypeBean(propertyTypeDao.getPropertyTypeById(rs.getInt("property_type_id")));
				property.setPname(rs.getString("pname"));
				property.setAddress(rs.getString("address"));
				property.setPropertyTag(rs.getString("property_tag"));
				property.setLongitude(rs.getDouble("longitude"));
				property.setLatitude(rs.getDouble("latitude"));
				property.setStatus(rs.getString("STATUS"));
				property.setRooms(rs.getInt("rooms"));
				property.setDrawingRoom(rs.getString("drawing_room"));
				property.setTotalArea(rs.getDouble("total_area"));
				property.setCoveredArea(rs.getDouble("covered_area"));
				property.setConstructionDate(rs.getDate("construction_date"));
				property.setPrice(rs.getDouble("price"));
				property.setWashrooms(rs.getInt("washroom"));
				property.setOwner(rs.getString("OWNER"));
				property.setCreatedAt(rs.getDate("created_at"));
				property.setUpdatedBy(rs.getInt("updated_by"));
				property.setCreatedBy(rs.getInt("created_by"));
				property.setUpdatedAt(rs.getDate("updated_at"));
				property.setActive(rs.getInt("active"));
				LocationDao locationDao = new LocationDaoImpl();
				property.setLocationBean(locationDao.getLocationById(rs.getInt("location_id")));
				properties.add(property);

			}
		} catch (Exception e) {
			System.out.println("Error in getAllProperties");
			e.printStackTrace();
		}

		return properties;

	}

}
