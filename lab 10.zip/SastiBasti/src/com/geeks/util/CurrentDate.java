package com.geeks.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;

public class CurrentDate {

	public static Date getCurrentDate() {

	    java.util.Date utilDate = new java.util.Date();
	    return new java.sql.Date(utilDate.getTime());
	}
}
