/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7.multithreading;

import java.util.Scanner;

public class MatrixMultiplication {

    public static void main(String[] args) {
        long endTime = 0, exectionTIme = 0;
        long startTime = System.currentTimeMillis();
        System.out.println("Start Time: " + startTime);
        int m = 10, n = 10, p = 10, q = 10, sum = 0, c, d, k;
        Scanner in = new Scanner(System.in);
        int first[][] = createMatrix(10, m, n);
        System.out.println("Enter elements of first matrix");
        System.out.println("Enter the number of rows and columns of second matrix");
        if (n != p) {
            System.out.println("The matrices can't be multiplied with each other.");
        } else {
            int second[][] = createMatrix(5, m, n);
            int multiply[][] = new int[m][q];

            System.out.println("Enter elements of second matrix");

            for (c = 0; c < m; c++) {
                for (d = 0; d < q; d++) {
                    for (k = 0; k < p; k++) {
                        sum = sum + first[c][k] * second[k][d];
                    }

                    multiply[c][d] = sum;
                    sum = 0;
                }
            }
              System.out.println("Product of the matrices:");

            for (c = 0; c < m; c++) {
                for (d = 0; d < q; d++) {
                    System.out.print(multiply[c][d] + "\t");
                }

                System.out.print("\n");
            }
        }endTime = System.currentTimeMillis();
        exectionTIme = endTime - startTime;
        System.out.println("End time " + endTime);
        System.out.println("Time of Exection:" + exectionTIme);

    }
    public static int[][] createMatrix(int value, int m, int n) {
        int[][] matrix = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = value;}}
return matrix;
    }}
