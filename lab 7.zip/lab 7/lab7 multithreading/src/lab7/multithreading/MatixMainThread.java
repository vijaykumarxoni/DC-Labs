package lab7.multithreading;

import java.util.Scanner;
public class MatixMainThread {
  public static int multiply[][] ;
 public static void main(String[] args) {
        long endTime=0,exectionTIme=0;
        long startTime=System.currentTimeMillis();
        System.out.println("Start Time: "+startTime);

        multiply = new int[10][10];
          
     int  [][] first = createMatrix(5,10,10);
     int [][] second = createMatrix(10,10,10);
      
     ThreadRow t1=new ThreadRow(first,second,0);
     ThreadRow t2=new ThreadRow(first,second,1);
     ThreadRow t3=new ThreadRow(first,second,2);
     ThreadRow t4=new ThreadRow(first,second,3);
     ThreadRow t5=new ThreadRow(first,second,4);
     ThreadRow t6=new ThreadRow(first,second,5);
     ThreadRow t7=new ThreadRow(first,second,6);
     ThreadRow t8=new ThreadRow(first,second,7);
     ThreadRow t9=new ThreadRow(first,second,8);
     ThreadRow t10=new ThreadRow(first,second,9);
     
     
     
     

       for (int c = 0; c < 10; c++)
         {
            for (int d = 0; d < 10; d++)
               System.out.print(multiply[c][d]+"\t");
 
            System.out.print("\n");
         }
      
     
                       endTime=System.currentTimeMillis();
                exectionTIme=endTime-startTime;
                System.out.println("End time "+endTime);
                System.out.println("Time of Exection:"+exectionTIme);

       
       
       }
       public static int[][] createMatrix(int value,int m, int n){

		int [][] matrix = new int[m][n];
		for (int i = 0; i < m ; i++ ) {
		    for (int j = 0; j < n ; j++ ) {
		    		matrix [i][j] = value;
		    	}	
		}

		return matrix;

	}
}

