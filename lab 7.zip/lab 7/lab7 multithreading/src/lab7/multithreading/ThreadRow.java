
package lab7.multithreading;
public class ThreadRow implements Runnable{
    int[][] first= new int[10][10];
    int[][] second= new int[10][10];
    Thread T;
    int m=10, n=10, p=10, q=10, sum = 0, c=0, d, k;
    public ThreadRow() {
    } 
   public ThreadRow(int[][] first,int[][] sencond, int c) {
        this.first=first;
        this.second=sencond;
        this.c=c;
        T = new Thread(this);
        T.start();        
    }
    @Override
    public void run() {
             for (d = 0; d < q; d++)
            {  
               for (k = 0; k < p; k++)
               {
                  sum = sum + first[c][k]*second[k][d];
               }
 
               MatixMainThread.multiply[c][d] = sum;
               sum = 0;
            }
         
    }
    
}
